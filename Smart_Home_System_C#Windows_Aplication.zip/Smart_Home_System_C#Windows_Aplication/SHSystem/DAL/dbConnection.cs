﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
     public class dbConnection
    {

        private string ConnectString;
        public SqlDataReader reader;
        private SqlConnection con;
        private SqlCommand cmd;

        public dbConnection( string ConnectParam="Connect")
        {
            this.ConnectString = ConfigurationManager.ConnectionStrings[ConnectParam].ConnectionString;
        }


        public DataTable ExecuteTree(string Text, CommandType CmdType)
        {
            try
            {
                con = new SqlConnection(ConnectString);
                SqlDataReader dr;

                //Opening Connection  
                if (con.State != ConnectionState.Open)
                    con.Open();

                cmd = new SqlCommand(Text, con);
                cmd.CommandType = CmdType; //Assign the SqlString Type to Command Object  

                dr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                //Loading all data in a datatable from datareader  
                dt.Load(dr);
                //Closing the connection  
                con.Close();
                return dt;
            }
            catch
            {
                throw;
            }

        }  


        public DataTable Select(string query)
        {
            DataTable dt;
            try
            {
                con = new SqlConnection(ConnectString);
                con.Open();
                string select = query;
                DataSet ds = new DataSet();
                SqlDataAdapter ad = new SqlDataAdapter(select, con);
                ad.Fill(ds);
                dt = ds.Tables[0];
            }
            catch
            {

                throw new MyException("Connection failed");
            }
                con.Close();
                return dt; 
                     
        }

        public DataTable SelectContract(string query)
        {
            DataTable dt;
            try
            {
                con = new SqlConnection(ConnectString);
                con.Open();
                string select = query;
                DataSet ds = new DataSet();
                SqlDataAdapter ad = new SqlDataAdapter(select, con);
                ad.Fill(ds);
                dt = ds.Tables[0];
            }
            catch 
            {

                throw new MyException("Connection failed");
            }
            
            con.Close();
            return dt;
        }

        public bool Update(string CommandName, CommandType cmdType, SqlParameter[] pars)
        {
            con = new SqlConnection(ConnectString);
            int result = 0;
            using (con)
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = cmdType;
                    cmd.CommandText = CommandName;
                    cmd.Parameters.AddRange(pars);

                    try
                    {
                        if (con.State != ConnectionState.Open)
                        {
                            con.Open();
                        }

                        result = cmd.ExecuteNonQuery();
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            return (result > 0);
        }

        public bool Insert(string CommandName, CommandType cmdType, SqlParameter[] pars)
        {
            con = new SqlConnection(ConnectString);
            int result = 0;
            using (con)
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = cmdType;
                    cmd.CommandText = CommandName;
                    cmd.Parameters.AddRange(pars);

                    try
                    {
                        if (con.State != ConnectionState.Open)
                        {
                            con.Open();
                        }

                        result = cmd.ExecuteNonQuery();
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            return (result > 0);
        }



         //Read

        public DataTable ReadDatabase(string CommandName, CommandType cmdType, SqlParameter[] param)
        {
            DataTable table = new DataTable();
            con = new SqlConnection(ConnectString);
            using (con)
            {
                using (SqlCommand cmd = con.CreateCommand())
                {
                    cmd.CommandType = cmdType;
                    cmd.CommandText = CommandName;
                    cmd.Parameters.AddRange(param);

                    try
                    {
                        if (con.State != ConnectionState.Open)
                        {
                            con.Open();
                        }

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(table);
                        }
                    }
                    catch
                    {
                        throw;
                    }
                }
            }

            return table;
        }

        
    }
}
