﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Person
    {
        public string name;
        public string surname;
        public string idNumber;
        public string address;
        public string contactNumber;
        public string addressNumber;
        public string surburb;
        public string postalCode;
        public string email;

        public string Name
        {
            get { return name; }
            set { name = value == null ? string.Empty : value.Trim(); }
        }

        public string Surname
        {
            get { return surname; }
            set { surname = value == null ? string.Empty : value.Trim(); ; }
        }

        public string IdNumber
        {
            get { return idNumber; }
            set { idNumber = value == null ? string.Empty : value.Trim(); ; }
        }

        public string ContactNumber
        {
            get { return contactNumber; }
            set { contactNumber = value == null ? string.Empty : value.Trim(); ; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value == null ? string.Empty : value.Trim(); ; }
        }

        public string Surburb
        {
            get { return surburb; }
            set { surburb = value == null ? string.Empty : value.Trim(); ; }
        }

        public string PostalCode
        {
            get { return postalCode; }
            set { postalCode = value == null ? string.Empty : value.Trim(); ; }
        }

        public Person()
        {

        }

        public Person(string name, string surname, string idNumber, string contactNumber, string email, string address, string surburb, string code)
        {
            this.Name = name;
            this.Surname = surname;
            this.IdNumber = idNumber;
            this.Address = address;
            this.ContactNumber = contactNumber;
            this.Surburb = surburb;
            this.postalCode = code;
            this.Email = email;
        }
    }
}
