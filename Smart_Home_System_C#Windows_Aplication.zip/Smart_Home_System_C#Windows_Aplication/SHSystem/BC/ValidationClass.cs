﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Drawing;

namespace BLL
{
  public  class ValidationClass
    {
        public static void Regexp(string re, TextBox tb, PictureBox pb)
        {
            Regex regex = new Regex(re);
            if (regex.IsMatch(tb.Text.ToString()))
            {
                pb.Image = Properties.Resources.valid;
              

            }
            else
            {
                pb.Image = Properties.Resources.invalid;
               
            }
        }

      
        public static void Regexp(string re, ComboBox cb, PictureBox pb, Label lbl, string s)
        {
            Regex regex = new Regex(re);
            if (regex.IsMatch(cb.Text))
            {
                pb.Image = Properties.Resources.valid;
                lbl.ForeColor = Color.Green;
                lbl.Text = s + "Valid";

            }
            else
            {
                pb.Image = Properties.Resources.invalid;
                lbl.ForeColor = Color.Red;
                lbl.Text = s + "Invalid";
            }
        }


        public static void Regexp(string re, NumericUpDown nud, PictureBox pb)
        {
            Regex regex = new Regex(re);
            if (regex.IsMatch(nud.Value.ToString()))
            {
                pb.Image = Properties.Resources.valid;
              

            }
            else
            {
                pb.Image = Properties.Resources.invalid;
                
            }

        }
    }
}
