﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    abstract class Supplier
    {
        public int supplierID;
        public string name;
        public string contactNumber;
        public string email;
        public string officeAddress;
        public string surburb;
        public string postalCode;

        public string PostalCode
        {
            get { return postalCode; }
            set { postalCode = value; }
        }



        public string Surburb
        {
            get { return surburb; }
            set { surburb = value; }
        }


        public string OfficeAddress
        {
            get { return officeAddress; }
            set { officeAddress = value; }
        }


        public string Email
        {
            get { return email; }
            set { email = value; }
        }


        public string ContactNumber
        {
            get { return contactNumber; }
            set { contactNumber = value; }
        }


        public string Name
        {
            get { return name; }
            set { name = value; }
        }


        public int SupplierID
        {
            get { return supplierID; }
            set { supplierID = value; }
        }

        public Supplier()
        {

        }

        public Supplier(int supplierID, string name, string contactNumber, string email, string officeaddress, string surburb, string postalCode)
        {
            this.SupplierID = supplierID;
            this.Name = name;
            this.ContactNumber = contactNumber;
            this.Email = email;
            this.OfficeAddress = officeaddress;
            this.Surburb = surburb;
            this.PostalCode = postalCode;
        }
    }
}
