﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.Data;

namespace BLL
{
    public class Users
    {
        private int userID;
        private string username;
        private string password;
        private int departmentID;
        private string securityQuestion;
        private string securityAnswer;

        public Users(int userID, string username, string password, int departmentID, string securityQuestion, string securityAnswer)
        {
            this.Username = username;
            this.Password = password;
            this.DepartmentID = departmentID;
        }

        public Users()
        {
                
        }

        public string SecurityAnswer
        {
            get { return securityAnswer; }
            set { securityAnswer = value; }
        }


        public string SecurityQuestion
        {
            get { return securityQuestion; }
            set { securityQuestion = value; }
        }

        public int DepartmentID
        {
            get { return departmentID; }
            set { departmentID = value; }
        }
        

        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        

        public string Username
        {
            get { return username; }
            set { username = value; }
        }

        public int UserID
        {
            get { return userID; }
            set { userID = value; }
        }

        public List<Users> UserLog()
        {
            dbConnection db = new dbConnection();
            List<Users> list = new List<Users>();
            string select = "Select * from tblUsers";
            foreach (DataRow item in db.Select(select).Rows)
            {
                list.Add(new Users(int.Parse(item[0].ToString()), item[1].ToString(), item[2].ToString(), int.Parse(item[3].ToString()), item[4].ToString(), item[5].ToString()));
            }
            return list;
        }
    }
}
