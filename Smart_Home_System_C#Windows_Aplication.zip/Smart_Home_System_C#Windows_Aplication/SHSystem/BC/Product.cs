﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;

namespace BLL
{
    public class Product
    {
        public int productID;
        public string productname;
        public string productdescription;
        private int categoryID;

        public int CategoryID
        {
            get { return categoryID; }
            set { categoryID = value; }
        }
        

        public string ProductDescription
        {
            get { return productdescription; }
            set { productdescription = value; }
        }
        

        public string productName
        {
            get { return productname; }
            set { productname = value; }
        }
        

        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }

        public Product(int productID, string name, string description,int categoryID)
        {
            ProductID = productID;
            productName = name;
            ProductDescription = description;
            CategoryID = categoryID;
        }

        public Product()
        {

        }

        public string OptionDisplay
        {
            get { return " Name :" + productname; }
        }

        public List<Product> ProductList()
        {
            dbConnection db = new dbConnection();
            List<Product> list = new List<Product>();
            string select = "Select * from tblProduct";
            foreach (DataRow item in db.Select(select).Rows)
            {
                list.Add(new Product(int.Parse(item[0].ToString()), item[1].ToString(), item[2].ToString(), int.Parse(item[3].ToString())));
            }
            return list;
        }
        

        public List<Product> ProductOnCategoty(string category)
        {
            dbConnection db = new dbConnection();
            List<Product> list = new List<Product>();
            string select = @"select * from tblProduct P inner join tblProductCategory PC on p.CategoryID=PC.CategoryID
where PC.CategoryName = '" + category + "'";
            foreach (DataRow item in db.Select(select).Rows)
            {
                list.Add(new Product(int.Parse(item[0].ToString()), item[1].ToString(), item[2].ToString(), int.Parse(item[3].ToString())));
            }
            return list;
        }
    }
}
