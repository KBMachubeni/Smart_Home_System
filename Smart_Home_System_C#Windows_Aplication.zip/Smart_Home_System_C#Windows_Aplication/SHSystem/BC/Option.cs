﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;

namespace BLL
{
    public class Option
    {
        public int optionID;
        public string optionDescription;        
        public double cost;
        private double monthfee;
        public int manufactureID;
        public string serialNumber;
        private int productID;

        public Option(int optionID, string description, int productID, int manufactureID, double cost, string serialNumber, double monthfee)
        {
            OptionID = optionID;
            OptionDescription = description;
            Cost = cost;
            ManufactureID = manufactureID;
            SerialNumber = serialNumber;
            ProductID = productID;
            Monthfee = monthfee;
        }

        public Option()
        {

        }

        public int OptionID
        {
            get { return optionID; }
            set { optionID = value; }
        }

        public string OptionDescription
        {
            get { return optionDescription; }
            set { optionDescription = value == null ? string.Empty : value.Trim(); ;  }
        }

        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }
        public double Cost
        {
            get { return cost; }
            set { cost = value; }
        }

        public int ManufactureID
        {
            get { return manufactureID; }
            set { manufactureID = value; }
        }

        public string SerialNumber
        {
            get { return serialNumber; }
            set { serialNumber = value == null ? string.Empty : value.Trim(); ;  }
        }

        public double Monthfee
        {
            get { return monthfee; }
            set { monthfee = value; }
        }
        

        public List<Option> OptiontList()
        {
            dbConnection db = new dbConnection();
            List<Option> list = new List<Option>();
            string select = "Select * from tblOption";
            foreach (DataRow item in db.Select(select).Rows)
            {
                Option opt = new Option();
                list.Add(new Option(int.Parse(item[0].ToString()), item[1].ToString(), int.Parse(item[2].ToString()), int.Parse(item[3].ToString()), double.Parse(item[4].ToString()), item[5].ToString(),double.Parse( item[6].ToString())));
            }
            return list;
        }

        public List<Option> OptiontOfProduct(int id)
        {
            dbConnection db = new dbConnection();
            List<Option> list = new List<Option>();
            string select = "Select * from tblOption where ProductID like '" + id + "' ";
            foreach (DataRow item in db.Select(select).Rows)
            {
                list.Add(new Option(int.Parse(item[0].ToString()), item[1].ToString(), int.Parse(item[2].ToString()), int.Parse(item[3].ToString()), double.Parse(item[4].ToString()), item[5].ToString(), double.Parse(item[6].ToString())));
            }
            return list;
        }

        public List<Option> ProductOption(int id)
        {
            List<Option> list = new List<Option>();
            string select = "Select * from tblOption where OptionID like '" + id + "' ";
            dbConnection db = new dbConnection();
            foreach (DataRow item in db.Select(select).Rows)
            {
                Option opt = new Option();
                list.Add(new Option(int.Parse(item[0].ToString()), item[1].ToString(), int.Parse(item[2].ToString()), int.Parse(item[3].ToString()), double.Parse(item[4].ToString()), item[5].ToString(), double.Parse(item[6].ToString())));
            }
            return list;
        }

        public string OptionDisplay
        {
            get { return "Description :" + OptionDescription + "\t" +"Serial Number: "+ SerialNumber; }
        }

        public override string ToString()
        {
            return OptionDisplay;
        }
    }
}
