﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DAL;

namespace BLL
{
    public class StoredProcedures
    {
        DAL.dbConnection connection = new dbConnection();

        #region call functions
        public bool RecordCall(Call call)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@Phonenumber", call.PhoneNumber),
			new SqlParameter("@CallDate", call.CallDate),
			new SqlParameter("@DurationInMinutes", call.Duration),
            new SqlParameter("@Description", call.Descrption),
            new SqlParameter("@Caller", call.Caller),
		};

            return connection.Update("sp_RecordCall", CommandType.StoredProcedure, parameters);
        }

        public DataTable RetieveCalls()
        {
            DataTable dt = new DataTable();
            string select = "select * from tblCalls";
            dt = connection.ExecuteTree(select, CommandType.Text);
            return dt;
        }

        #endregion

        #region PersonalSchedule
        public DataTable GetPersonnelData()
        {
                DataTable dt = new DataTable();
                string select = "Select Names,Surname,EmployeelID from tblEmployee where PositionID =2";
                dt = connection.ExecuteTree(select, CommandType.Text); 
                return dt;
        }
        public DataTable GetPersonnelSchedule(string id)
        {
            DataTable dt = new DataTable();
            int PersonnelID = int.Parse(id);
            string select = "Select Names,Surname,EmployeelID from tblEmployee where EmployeelID ='" + id + "'";
            dt = connection.ExecuteTree(select, CommandType.Text);
            return dt;
        }

        #endregion 

        #region Clients Fucntions

        //Adding New sale
        public bool AddNew(Client client, Contract contract)
        {
            Installation isntal = new Installation();
            SqlParameter[] parameters = new SqlParameter[]
		{                
			new SqlParameter("@Name", client.Name),
			new SqlParameter("@Surname", client.Surname),
			new SqlParameter("@IdNumber",client.IdNumber),
			new SqlParameter("@ContactNumber",client.ContactNumber),
			new SqlParameter("@EmailAddress",client.Email),
			new SqlParameter("@AddressNumber",client.Address),
            new SqlParameter("@Surburb",client.Surburb),
            new SqlParameter("@PostalCode",client.PostalCode),

			new SqlParameter("@SignedDate",contract.SignedDate),
            new SqlParameter("@PaymentMade",contract.PaymentMade),
            new SqlParameter("@OptionID",contract.OptionID),
            new SqlParameter("@ServiceLevelID",contract.ServiceLevelID),
            new SqlParameter("@ContractTypeID",contract.ContactTypeID),
            new SqlParameter("@status",contract.ContractStatus),

            new SqlParameter("@startDate",isntal.defaultdate),
            new SqlParameter("@endDate",isntal.defaultdate)
		};

            return connection.Insert("sp_AddNew", CommandType.StoredProcedure, parameters);
        }
        //public bool Addproduct(Product product) 
        //{
        //    SqlParameter[] parameters = new SqlParameter[]
        //    { 
            
            
            
            
        //    };
        //}


        //Add new Client
        public bool AddClient(Client client)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{                
			new SqlParameter("@Name", client.Name),
			new SqlParameter("@Surname", client.Surname),
			new SqlParameter("@IdNumber",client.IdNumber),
			new SqlParameter("@ContactNumber",client.ContactNumber),
			new SqlParameter("@EmailAddress",client.Email),
			new SqlParameter("@AddressNumber",client.Address),
			new SqlParameter("@Surburb",client.Surburb),
			new SqlParameter("@PostalCode",client.PostalCode),
            new SqlParameter("@ClientIdentifier",client.ClientIdentifier)
		};

            return connection.Insert("sp_InsertClient", CommandType.StoredProcedure, parameters);
        }

        //Update Client
        public bool UpdateClient(Client client)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@id", client.ClientID),
			new SqlParameter("@name", client.Name),
			new SqlParameter("@Surname", client.Surname),
			new SqlParameter("@IDNumber", client.IdNumber),
			new SqlParameter("@ContactNumber", client.ContactNumber),
			new SqlParameter("@EmailAddress", client.Email),
            new SqlParameter("@Address", client.Address),
            new SqlParameter("@Surburb", client.Surburb),
            new SqlParameter("@Postal", client.PostalCode)
		};

            return connection.Update("sp_UpdateClient", CommandType.StoredProcedure, parameters);
        }
        #endregion

        #region Personnel Fucntions

        //Search free Employee
        public Employee FreeEmployee(DateTime d1, DateTime d2)
        {
            Employee emp = null;

            SqlParameter[] parameters = new SqlParameter[]
        {
            new SqlParameter("@Date1", d1),
            new SqlParameter("@Date2", d2)
        };
            using (DataTable table = connection.ReadDatabase("sp_SelectFreeEmployee", CommandType.StoredProcedure, parameters))
            {
                if (table.Rows.Count == 1)
                {
                    DataRow row = table.Rows[0];
                    emp.Name = row["LastName"].ToString();
                    emp.Surname = row["LastName"].ToString();
                    emp.IdNumber = row["LastName"].ToString();
                    emp.EmployeeID = Convert.ToInt32(row["LastName"].ToString());
                    emp.ContactNumber = row["LastName"].ToString();
                }
            }

            return emp;
        }

        //Schedule Employee
        public bool ScheduleAdd(Employee employee, Installation install)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{                
			new SqlParameter("@PersonnelID",employee.EmployeeID),
			new SqlParameter("@InstallationID",install.InstallationID)
		};

            return connection.Insert("sp_ScheduleInstall", CommandType.StoredProcedure, parameters);
        }

        //Update Employee
        public bool UpdateEmployee(Employee employee)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@id", employee.EmployeeID),
			new SqlParameter("@name", employee.Name),
			new SqlParameter("@Surname", employee.Surname),
			new SqlParameter("@IDNumber", employee.IdNumber),
			new SqlParameter("@ContactNumber", employee.ContactNumber),
			new SqlParameter("@EmailAddress", employee.Email)
		};

            return connection.Update("sp_UpdateEmployee", CommandType.StoredProcedure, parameters);
        }

        //Add Employee
        public bool AddEmployee(Employee employee)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
			new SqlParameter("@name", employee.Name),
			new SqlParameter("@Surname", employee.Surname),
			new SqlParameter("@IDNumber", employee.IdNumber),
			new SqlParameter("@ContactNumber", employee.ContactNumber),
            new SqlParameter("@EmailAddress", employee.Email),
			new SqlParameter("@Salary", employee.Salary),
            new SqlParameter("@AddressNumber", employee.Address),
            new SqlParameter("@Surburb", employee.Surburb),
            new SqlParameter("@PostalCode", employee.PostalCode),
            new SqlParameter("@DepartmentID", 1),
            new SqlParameter("@PositionID", 2)
		};

            return connection.Insert("sp_InsertEmployee", CommandType.StoredProcedure, parameters);
        }

        #endregion

        #region Contract Fucntions

        //Add Contract
        public bool AddContract(Contract contarct)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{                
			new SqlParameter("@Identifier",contarct.Identifier),
			new SqlParameter("@SignedDate",contarct.SignedDate),
			new SqlParameter("@PaymentMade",contarct.PaymentMade),
			new SqlParameter("@OptionID",contarct.OptionID),
			new SqlParameter("@ServiceLevelID",contarct.ServiceLevelID),
			new SqlParameter("@ContractTypeID",contarct.ContactTypeID),
			new SqlParameter("@ClientID",contarct.ClientID)
		};

            return connection.Insert("sp_InsertContract", CommandType.StoredProcedure, parameters);
        }

        //Update Contract
        public bool UpdateContract(Contract contract)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@id", contract.ContractID),
			new SqlParameter("@ContractStatus", contract.ContractStatus),
            new SqlParameter("@Service", contract.ServiceLevelID),
            new SqlParameter("@Type ", contract.ContactTypeID)
		};

            return connection.Update("sp_UpdateContract", CommandType.StoredProcedure, parameters);
        }
        #endregion

        #region Installation Fucntions

        //Update Installation
        public bool UpdateInstallation(Installation instal)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@id", instal.InstallationID),
			new SqlParameter("@InstallationStartDate", instal.StartDate),
			new SqlParameter("@InstallationEndDate", instal.EndDate)
		};

            return connection.Update("sp_UpdateInstallation", CommandType.StoredProcedure, parameters);
        }
        #endregion

        #region Maintenace Fucntions

        //Schedule MAintenance
        public bool MaintScheduleAdd(Employee employee, Maintenance maint)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{                
			new SqlParameter("@PersonnelID",employee.EmployeeID),
			new SqlParameter("@MaintenanceID",maint.MaintenanceID)
		};

            return connection.Insert("sp_ScheduleMaint", CommandType.StoredProcedure, parameters);
        }

        //Add Maintenance
        public bool AddMaintenance(Maintenance maint)
        {
            SqlParameter[] parameters = new SqlParameter[]
	        	{
			new SqlParameter("@Discription", maint.Description),
			new SqlParameter("@MaintenanceStartDate", maint.defaultdate),
			new SqlParameter("@MaintenanceEndDate", maint.defaultdate),
            new SqlParameter("@ContractID", maint.ContractID)
		        };
            return connection.Update("sp_AddMaintenace", CommandType.StoredProcedure, parameters);
        }

        //Schedule MAintenance
        public bool ScheduleMaintenance(Maintenance maint)
        {
            SqlParameter[] parameters = new SqlParameter[]
	        	{
            new SqlParameter("@id", maint.MaintenanceID),
			new SqlParameter("@MaintenanceStartDate", maint.StartDate),
			new SqlParameter("@MaintenanceEndDate", maint.EndDate),
			new SqlParameter("@MaintenanceCost", maint.Cost)
		        };
            return connection.Update("sp_ScheduleMaintenace", CommandType.StoredProcedure, parameters);
        }

        //Update Maintenance
        public bool UpdateMaintenance(Maintenance maint)
        {
            SqlParameter[] parameters = new SqlParameter[]
	        	{
			new SqlParameter("@MaintenanceDescription", maint.Description),
            new SqlParameter("@id", maint.MaintenanceID)
		        };
            return connection.Update("sp_UpdateMaintenance", CommandType.StoredProcedure, parameters);
        }

        #endregion

        #region Products Fucntions

        //Update Product
        public bool UpdateProduct(Product product)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@ProductID", product.productID),
			new SqlParameter("@ProductName", product.productName),
            new SqlParameter("@ProductDescription", product.ProductDescription)
		};

            return connection.Update("sp_UpdateProduct", CommandType.StoredProcedure, parameters);
        }
        #endregion

        #region Options Fucntions

        #endregion

        #region User Fucntions
        public bool AddUser(Users user)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
			new SqlParameter("@Username", user.Username),
			new SqlParameter("@Password", user.Password),
			new SqlParameter("@departmentID", user.DepartmentID),
			new SqlParameter("@SecurityQuestion", user.SecurityQuestion),
            new SqlParameter("@SecurityAnswer", user.SecurityAnswer)
		};

            return connection.Insert("sp_RegisterUser", CommandType.StoredProcedure, parameters);
        }

        public bool UpdateUser(Users user)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
			new SqlParameter("@Username", user.Username),
			new SqlParameter("@Password", user.Password)
		};

            return connection.Update("sp_UpDateUser", CommandType.StoredProcedure, parameters);
        }
        #endregion
      
    }
}
