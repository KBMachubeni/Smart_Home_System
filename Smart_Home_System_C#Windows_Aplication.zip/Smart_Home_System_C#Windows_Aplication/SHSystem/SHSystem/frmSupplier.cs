﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SHSystem
{
    public partial class frmSupplier : Form
    {
        public frmSupplier()
        {
            InitializeComponent();
        }
            DataTable table = new DataTable();
            DataAccesss access = new DataAccesss();
            
        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void frmSupplier_Load(object sender, EventArgs e)
        {
          //  table = access.Supplier();
            dgvSupplier.DataSource = table; 
        }

        private void dgvSupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvSupplier.CurrentCell.RowIndex;
            txtName.Text = dgvSupplier[1, current].Value.ToString();
            txtSurname.Text = dgvSupplier[2, current].Value.ToString();
            txtEmail.Text = dgvSupplier[3, current].Value.ToString();
            txtAddress.Text = dgvSupplier[4, current].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void btnBacks_Click(object sender, EventArgs e)
        {
            frmPRManagemet pr = new frmPRManagemet();
            pr.Show();
            this.Hide();
        }
    }
}
