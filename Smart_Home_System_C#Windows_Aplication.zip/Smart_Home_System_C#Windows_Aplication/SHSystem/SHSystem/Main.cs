﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SHSystem
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
        public Main(string user)
        {
            InitializeComponent();
            txtLuser.Text = user;
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Clients cm = new Clients();
            cm.Show();
            this.Hide();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmSignIn SIGN = new frmSignIn();
            this.Hide();
            SIGN.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmRegisterUser ru = new frmRegisterUser();
            ru.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmTechSupport tech = new frmTechSupport();
            this.Hide();
            tech.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmCallCentre call = new frmCallCentre();
            call.Show();
            this.Hide();
        }

        private void btnProductManagement_Click(object sender, EventArgs e)
        {
            frmPRManagemet pr = new frmPRManagemet();
            pr.Show();
            this.Hide();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            
        }
    }
}
