﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmSignIn : Form
    {
        public frmSignIn()
        {
            InitializeComponent();
        }

        Users user = new Users();
        int attempst = 3;


        private void btnSignIn_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == "" || txtUsename.Text == "")
            {
                MessageBox.Show("Please Fill both fields");
                return;
            }
            List<Users> userlist = user.UserLog();

            foreach (var item in userlist)
            {
                if (txtUsename.Text == item.Username && txtPassword.Text == item.Password)
                {
                    if (item.DepartmentID == 1)
                    {
                        MessageBox.Show("Welcome   " + txtUsename.Text);
                        Main m = new Main();
                        m.Show();
                        
                        //Clients cm = new Clients(txtUsename.Text);
                        //cm.Show();
                        this.Hide();
                        return;
                    }
                    if (item.DepartmentID == 2)
                    {
                        MessageBox.Show("Welcome   " + txtUsename.Text);
                        frmTechSupport cm = new frmTechSupport();
                        cm.Show();
                        this.Hide();
                        return;
                    }
                    if (item.DepartmentID == 3)
                    {
                        MessageBox.Show("Welcome    " + txtUsename.Text);
                        frmPRManagemet PR = new frmPRManagemet();
                        PR.Show();
                        this.Hide();
                        return;
                    }
                    if (item.DepartmentID == 4)
                    {
                        MessageBox.Show("Welcome   " + txtUsename.Text);
                        frmCallCentre call = new frmCallCentre();
                        call.Show();
                        this.Hide();
                        return;
                    }
                    else
                    {
                        MessageBox.Show("Incorrect credentials you have" + attempst + "left", "Log in fail", MessageBoxButtons.OK);
                        attempst--;
                        if (attempst == 0)
                        {
                            MessageBox.Show("You have used all atempts", "Press okay to change password", MessageBoxButtons.OK);
                            btnSignIn.Visible = false;
                        }
                        return;
                    }
                }
            

            }
        }

        private void frmSignIn_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtPassword.Clear();
            txtUsename.Clear();
        }

        private void label3_Click(object sender, EventArgs e)
        {
           frmRegisterUser Signin= new frmRegisterUser();
           Signin.Show();
           this.Hide();
        }
    }
}