using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace SHSystem
{
    class DataAccesss
    {
        private dbConnect conn;

        public DataAccesss()
        {
            conn = new dbConnect();
        }
        public DataTable SelectClient()
        {
            string query = "Select * from [tblClient]";
            return conn.executeSelectQuery(query);
        }


        public void UpdateClient(string name, string surname, string ID, string CN1, string CN2, string EM, int age, string HA, int id)
        {
            conn.UpdateClient( name, surname, ID, CN1, CN2, EM,age,HA, id);
        }

        public DataTable SearchClient(string ID)
        {
            string query = "Select * from [tblClient] Where [IdNumber] Like '" + ID + "'";
            return conn.executeSelectQuery(query);
        }
    }
}
























































