﻿namespace SHSystem
{
    partial class frmTechSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTechSupport));
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbpAddPerson = new System.Windows.Forms.TabPage();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAddPost = new System.Windows.Forms.TextBox();
            this.txtAddSurburb = new System.Windows.Forms.TextBox();
            this.txtAddID = new System.Windows.Forms.TextBox();
            this.txtAddSurname = new System.Windows.Forms.TextBox();
            this.txtAddAddress = new System.Windows.Forms.TextBox();
            this.txtAddCont = new System.Windows.Forms.TextBox();
            this.txtAddEmail = new System.Windows.Forms.TextBox();
            this.txtAddSalary = new System.Windows.Forms.TextBox();
            this.txtAddName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tbpMaintenace = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.TextBox();
            this.btnReqMaint = new System.Windows.Forms.Button();
            this.btnSearchFree = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.dtpD1 = new System.Windows.Forms.DateTimePicker();
            this.dtpD2 = new System.Windows.Forms.DateTimePicker();
            this.dgvFree = new System.Windows.Forms.DataGridView();
            this.btnSchedMaint = new System.Windows.Forms.Button();
            this.btnSetDate = new System.Windows.Forms.Button();
            this.dgvReqMainten = new System.Windows.Forms.DataGridView();
            this.tbpInstal = new System.Windows.Forms.TabPage();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.btnFreePerson = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.dtpDate2 = new System.Windows.Forms.DateTimePicker();
            this.dtpDate1 = new System.Windows.Forms.DateTimePicker();
            this.btnViewRequired = new System.Windows.Forms.Button();
            this.dgvFreePersonnel = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.btnScheduleDates = new System.Windows.Forms.Button();
            this.dgvRequired = new System.Windows.Forms.DataGridView();
            this.tbpView = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtPostal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSurbub = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.txtContactNumber = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtHome = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dgvPersonnel = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.button2 = new System.Windows.Forms.Button();
            this.tbpAddPerson.SuspendLayout();
            this.tbpMaintenace.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFree)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReqMainten)).BeginInit();
            this.tbpInstal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreePersonnel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequired)).BeginInit();
            this.tbpView.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonnel)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Snow;
            this.btnSearch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Snow;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.ForeColor = System.Drawing.Color.Snow;
            this.btnSearch.Location = new System.Drawing.Point(169, 62);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(24, 23);
            this.btnSearch.TabIndex = 64;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(16, 64);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(147, 20);
            this.txtSearch.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(18, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 62;
            this.label1.Text = "Search By ID:";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.button1.Location = new System.Drawing.Point(2, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 30);
            this.button1.TabIndex = 70;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // tbpAddPerson
            // 
            this.tbpAddPerson.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpAddPerson.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbpAddPerson.Controls.Add(this.btnCancel);
            this.tbpAddPerson.Controls.Add(this.btnSave);
            this.tbpAddPerson.Controls.Add(this.label11);
            this.tbpAddPerson.Controls.Add(this.label12);
            this.tbpAddPerson.Controls.Add(this.txtAddPost);
            this.tbpAddPerson.Controls.Add(this.txtAddSurburb);
            this.tbpAddPerson.Controls.Add(this.txtAddID);
            this.tbpAddPerson.Controls.Add(this.txtAddSurname);
            this.tbpAddPerson.Controls.Add(this.txtAddAddress);
            this.tbpAddPerson.Controls.Add(this.txtAddCont);
            this.tbpAddPerson.Controls.Add(this.txtAddEmail);
            this.tbpAddPerson.Controls.Add(this.txtAddSalary);
            this.tbpAddPerson.Controls.Add(this.txtAddName);
            this.tbpAddPerson.Controls.Add(this.label13);
            this.tbpAddPerson.Controls.Add(this.label14);
            this.tbpAddPerson.Controls.Add(this.label15);
            this.tbpAddPerson.Controls.Add(this.label16);
            this.tbpAddPerson.Controls.Add(this.label17);
            this.tbpAddPerson.Controls.Add(this.label18);
            this.tbpAddPerson.Controls.Add(this.label19);
            this.tbpAddPerson.Location = new System.Drawing.Point(4, 25);
            this.tbpAddPerson.Name = "tbpAddPerson";
            this.tbpAddPerson.Size = new System.Drawing.Size(742, 430);
            this.tbpAddPerson.TabIndex = 5;
            this.tbpAddPerson.Text = "Add Personnel";
            this.tbpAddPerson.Click += new System.EventHandler(this.tbpAddPerson_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnCancel.Location = new System.Drawing.Point(579, 348);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(89, 62);
            this.btnCancel.TabIndex = 157;
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSave.Location = new System.Drawing.Point(73, 355);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(72, 49);
            this.btnSave.TabIndex = 156;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click_2);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(567, 196);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(40, 15);
            this.label11.TabIndex = 155;
            this.label11.Text = "Code";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(368, 196);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 15);
            this.label12.TabIndex = 154;
            this.label12.Text = "Surburb";
            // 
            // txtAddPost
            // 
            this.txtAddPost.ForeColor = System.Drawing.Color.Black;
            this.txtAddPost.Location = new System.Drawing.Point(570, 219);
            this.txtAddPost.Multiline = true;
            this.txtAddPost.Name = "txtAddPost";
            this.txtAddPost.Size = new System.Drawing.Size(98, 23);
            this.txtAddPost.TabIndex = 153;
            // 
            // txtAddSurburb
            // 
            this.txtAddSurburb.ForeColor = System.Drawing.Color.Black;
            this.txtAddSurburb.Location = new System.Drawing.Point(371, 219);
            this.txtAddSurburb.Multiline = true;
            this.txtAddSurburb.Name = "txtAddSurburb";
            this.txtAddSurburb.Size = new System.Drawing.Size(180, 23);
            this.txtAddSurburb.TabIndex = 152;
            // 
            // txtAddID
            // 
            this.txtAddID.ForeColor = System.Drawing.Color.Black;
            this.txtAddID.Location = new System.Drawing.Point(373, 157);
            this.txtAddID.Name = "txtAddID";
            this.txtAddID.Size = new System.Drawing.Size(188, 20);
            this.txtAddID.TabIndex = 144;
            // 
            // txtAddSurname
            // 
            this.txtAddSurname.ForeColor = System.Drawing.Color.Black;
            this.txtAddSurname.Location = new System.Drawing.Point(73, 157);
            this.txtAddSurname.Name = "txtAddSurname";
            this.txtAddSurname.Size = new System.Drawing.Size(227, 20);
            this.txtAddSurname.TabIndex = 143;
            // 
            // txtAddAddress
            // 
            this.txtAddAddress.ForeColor = System.Drawing.Color.Black;
            this.txtAddAddress.Location = new System.Drawing.Point(73, 222);
            this.txtAddAddress.Name = "txtAddAddress";
            this.txtAddAddress.Size = new System.Drawing.Size(227, 20);
            this.txtAddAddress.TabIndex = 142;
            // 
            // txtAddCont
            // 
            this.txtAddCont.ForeColor = System.Drawing.Color.Black;
            this.txtAddCont.Location = new System.Drawing.Point(73, 280);
            this.txtAddCont.Name = "txtAddCont";
            this.txtAddCont.Size = new System.Drawing.Size(227, 20);
            this.txtAddCont.TabIndex = 141;
            // 
            // txtAddEmail
            // 
            this.txtAddEmail.ForeColor = System.Drawing.Color.Black;
            this.txtAddEmail.Location = new System.Drawing.Point(373, 95);
            this.txtAddEmail.Name = "txtAddEmail";
            this.txtAddEmail.Size = new System.Drawing.Size(256, 20);
            this.txtAddEmail.TabIndex = 140;
            // 
            // txtAddSalary
            // 
            this.txtAddSalary.ForeColor = System.Drawing.Color.Black;
            this.txtAddSalary.Location = new System.Drawing.Point(371, 277);
            this.txtAddSalary.Multiline = true;
            this.txtAddSalary.Name = "txtAddSalary";
            this.txtAddSalary.Size = new System.Drawing.Size(180, 21);
            this.txtAddSalary.TabIndex = 139;
            // 
            // txtAddName
            // 
            this.txtAddName.ForeColor = System.Drawing.Color.Black;
            this.txtAddName.Location = new System.Drawing.Point(73, 95);
            this.txtAddName.Name = "txtAddName";
            this.txtAddName.Size = new System.Drawing.Size(227, 20);
            this.txtAddName.TabIndex = 138;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(70, 262);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(110, 15);
            this.label13.TabIndex = 151;
            this.label13.Text = "Contact Number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(368, 259);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 15);
            this.label14.TabIndex = 150;
            this.label14.Text = "Salary";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(70, 68);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 15);
            this.label15.TabIndex = 149;
            this.label15.Text = "Name";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(70, 130);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(65, 15);
            this.label16.TabIndex = 148;
            this.label16.Text = "Surname";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(370, 127);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(76, 15);
            this.label17.TabIndex = 147;
            this.label17.Text = "ID Number";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(80, 199);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 15);
            this.label18.TabIndex = 146;
            this.label18.Text = "Home Address";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(370, 73);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 15);
            this.label19.TabIndex = 145;
            this.label19.Text = "Email Address";
            // 
            // tbpMaintenace
            // 
            this.tbpMaintenace.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpMaintenace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbpMaintenace.Controls.Add(this.label27);
            this.tbpMaintenace.Controls.Add(this.label26);
            this.tbpMaintenace.Controls.Add(this.label25);
            this.tbpMaintenace.Controls.Add(this.txtCost);
            this.tbpMaintenace.Controls.Add(this.btnReqMaint);
            this.tbpMaintenace.Controls.Add(this.btnSearchFree);
            this.tbpMaintenace.Controls.Add(this.label23);
            this.tbpMaintenace.Controls.Add(this.label24);
            this.tbpMaintenace.Controls.Add(this.dtpD1);
            this.tbpMaintenace.Controls.Add(this.dtpD2);
            this.tbpMaintenace.Controls.Add(this.dgvFree);
            this.tbpMaintenace.Controls.Add(this.btnSchedMaint);
            this.tbpMaintenace.Controls.Add(this.btnSetDate);
            this.tbpMaintenace.Controls.Add(this.dgvReqMainten);
            this.tbpMaintenace.Location = new System.Drawing.Point(4, 25);
            this.tbpMaintenace.Name = "tbpMaintenace";
            this.tbpMaintenace.Size = new System.Drawing.Size(742, 430);
            this.tbpMaintenace.TabIndex = 3;
            this.tbpMaintenace.Text = "Maintenance";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(352, 394);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(180, 20);
            this.label27.TabIndex = 26;
            this.label27.Text = "Schedule Maintenance :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(352, 354);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(176, 20);
            this.label26.TabIndex = 25;
            this.label26.Text = "Search Free Personnel:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(15, 408);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(34, 13);
            this.label25.TabIndex = 24;
            this.label25.Text = "Cost :";
            // 
            // txtCost
            // 
            this.txtCost.Location = new System.Drawing.Point(109, 405);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(200, 20);
            this.txtCost.TabIndex = 23;
            // 
            // btnReqMaint
            // 
            this.btnReqMaint.ForeColor = System.Drawing.Color.Black;
            this.btnReqMaint.Location = new System.Drawing.Point(5, 26);
            this.btnReqMaint.Name = "btnReqMaint";
            this.btnReqMaint.Size = new System.Drawing.Size(304, 43);
            this.btnReqMaint.TabIndex = 22;
            this.btnReqMaint.Text = "Required Maintenace";
            this.btnReqMaint.UseVisualStyleBackColor = true;
            this.btnReqMaint.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnSearchFree
            // 
            this.btnSearchFree.BackColor = System.Drawing.Color.Transparent;
            this.btnSearchFree.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearchFree.BackgroundImage")));
            this.btnSearchFree.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearchFree.FlatAppearance.BorderSize = 0;
            this.btnSearchFree.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchFree.ForeColor = System.Drawing.Color.Black;
            this.btnSearchFree.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.btnSearchFree.Location = new System.Drawing.Point(551, 344);
            this.btnSearchFree.Name = "btnSearchFree";
            this.btnSearchFree.Size = new System.Drawing.Size(34, 30);
            this.btnSearchFree.TabIndex = 21;
            this.btnSearchFree.UseVisualStyleBackColor = false;
            this.btnSearchFree.Click += new System.EventHandler(this.btnSearchFree_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(15, 379);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 13);
            this.label23.TabIndex = 20;
            this.label23.Text = "End Date :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(15, 359);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(61, 13);
            this.label24.TabIndex = 19;
            this.label24.Text = "Start Date :";
            // 
            // dtpD1
            // 
            this.dtpD1.Location = new System.Drawing.Point(109, 379);
            this.dtpD1.Name = "dtpD1";
            this.dtpD1.Size = new System.Drawing.Size(200, 20);
            this.dtpD1.TabIndex = 18;
            // 
            // dtpD2
            // 
            this.dtpD2.Location = new System.Drawing.Point(109, 353);
            this.dtpD2.Name = "dtpD2";
            this.dtpD2.Size = new System.Drawing.Size(200, 20);
            this.dtpD2.TabIndex = 17;
            // 
            // dgvFree
            // 
            this.dgvFree.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFree.Location = new System.Drawing.Point(315, 75);
            this.dgvFree.Name = "dgvFree";
            this.dgvFree.Size = new System.Drawing.Size(422, 262);
            this.dgvFree.TabIndex = 16;
            // 
            // btnSchedMaint
            // 
            this.btnSchedMaint.ForeColor = System.Drawing.Color.Black;
            this.btnSchedMaint.Location = new System.Drawing.Point(315, 26);
            this.btnSchedMaint.Name = "btnSchedMaint";
            this.btnSchedMaint.Size = new System.Drawing.Size(422, 43);
            this.btnSchedMaint.TabIndex = 15;
            this.btnSchedMaint.Text = "Schedule Personnel";
            this.btnSchedMaint.UseVisualStyleBackColor = true;
            this.btnSchedMaint.Click += new System.EventHandler(this.btnSchedMaint_Click);
            // 
            // btnSetDate
            // 
            this.btnSetDate.BackColor = System.Drawing.Color.Transparent;
            this.btnSetDate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSetDate.BackgroundImage")));
            this.btnSetDate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSetDate.FlatAppearance.BorderSize = 0;
            this.btnSetDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSetDate.ForeColor = System.Drawing.Color.Black;
            this.btnSetDate.Location = new System.Drawing.Point(555, 389);
            this.btnSetDate.Name = "btnSetDate";
            this.btnSetDate.Size = new System.Drawing.Size(30, 25);
            this.btnSetDate.TabIndex = 14;
            this.btnSetDate.UseVisualStyleBackColor = false;
            this.btnSetDate.Click += new System.EventHandler(this.btnSetDate_Click);
            // 
            // dgvReqMainten
            // 
            this.dgvReqMainten.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReqMainten.Location = new System.Drawing.Point(5, 75);
            this.dgvReqMainten.Name = "dgvReqMainten";
            this.dgvReqMainten.Size = new System.Drawing.Size(304, 262);
            this.dgvReqMainten.TabIndex = 13;
            this.dgvReqMainten.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReqMainten_CellContentClick);
            // 
            // tbpInstal
            // 
            this.tbpInstal.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpInstal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbpInstal.Controls.Add(this.label28);
            this.tbpInstal.Controls.Add(this.label29);
            this.tbpInstal.Controls.Add(this.btnFreePerson);
            this.tbpInstal.Controls.Add(this.label21);
            this.tbpInstal.Controls.Add(this.label20);
            this.tbpInstal.Controls.Add(this.dtpDate2);
            this.tbpInstal.Controls.Add(this.dtpDate1);
            this.tbpInstal.Controls.Add(this.btnViewRequired);
            this.tbpInstal.Controls.Add(this.dgvFreePersonnel);
            this.tbpInstal.Controls.Add(this.button3);
            this.tbpInstal.Controls.Add(this.btnScheduleDates);
            this.tbpInstal.Controls.Add(this.dgvRequired);
            this.tbpInstal.Location = new System.Drawing.Point(4, 25);
            this.tbpInstal.Name = "tbpInstal";
            this.tbpInstal.Size = new System.Drawing.Size(742, 430);
            this.tbpInstal.TabIndex = 2;
            this.tbpInstal.Text = " Installations";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(331, 394);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(180, 20);
            this.label28.TabIndex = 28;
            this.label28.Text = "Schedule Maintenance :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(331, 354);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(176, 20);
            this.label29.TabIndex = 27;
            this.label29.Text = "Search Free Personnel:";
            // 
            // btnFreePerson
            // 
            this.btnFreePerson.BackColor = System.Drawing.Color.Transparent;
            this.btnFreePerson.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFreePerson.BackgroundImage")));
            this.btnFreePerson.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFreePerson.FlatAppearance.BorderSize = 0;
            this.btnFreePerson.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFreePerson.Location = new System.Drawing.Point(518, 349);
            this.btnFreePerson.Name = "btnFreePerson";
            this.btnFreePerson.Size = new System.Drawing.Size(35, 30);
            this.btnFreePerson.TabIndex = 11;
            this.btnFreePerson.UseVisualStyleBackColor = false;
            this.btnFreePerson.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(12, 393);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 13);
            this.label21.TabIndex = 8;
            this.label21.Text = "End Date :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(12, 358);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 13);
            this.label20.TabIndex = 7;
            this.label20.Text = "Start Date :";
            // 
            // dtpDate2
            // 
            this.dtpDate2.Location = new System.Drawing.Point(107, 393);
            this.dtpDate2.Name = "dtpDate2";
            this.dtpDate2.Size = new System.Drawing.Size(200, 20);
            this.dtpDate2.TabIndex = 6;
            // 
            // dtpDate1
            // 
            this.dtpDate1.Location = new System.Drawing.Point(107, 352);
            this.dtpDate1.Name = "dtpDate1";
            this.dtpDate1.Size = new System.Drawing.Size(200, 20);
            this.dtpDate1.TabIndex = 5;
            // 
            // btnViewRequired
            // 
            this.btnViewRequired.ForeColor = System.Drawing.Color.Black;
            this.btnViewRequired.Location = new System.Drawing.Point(3, 35);
            this.btnViewRequired.Name = "btnViewRequired";
            this.btnViewRequired.Size = new System.Drawing.Size(304, 43);
            this.btnViewRequired.TabIndex = 4;
            this.btnViewRequired.Text = "Required Installations";
            this.btnViewRequired.UseVisualStyleBackColor = true;
            this.btnViewRequired.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvFreePersonnel
            // 
            this.dgvFreePersonnel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFreePersonnel.Location = new System.Drawing.Point(313, 84);
            this.dgvFreePersonnel.Name = "dgvFreePersonnel";
            this.dgvFreePersonnel.Size = new System.Drawing.Size(422, 262);
            this.dgvFreePersonnel.TabIndex = 3;
            this.dgvFreePersonnel.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFreePersonnel_CellContentClick);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(313, 35);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(422, 43);
            this.button3.TabIndex = 2;
            this.button3.Text = "Schedule Personnel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnScheduleDates
            // 
            this.btnScheduleDates.BackColor = System.Drawing.Color.Transparent;
            this.btnScheduleDates.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnScheduleDates.BackgroundImage")));
            this.btnScheduleDates.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnScheduleDates.FlatAppearance.BorderSize = 0;
            this.btnScheduleDates.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnScheduleDates.ForeColor = System.Drawing.Color.Black;
            this.btnScheduleDates.Location = new System.Drawing.Point(513, 386);
            this.btnScheduleDates.Name = "btnScheduleDates";
            this.btnScheduleDates.Size = new System.Drawing.Size(40, 28);
            this.btnScheduleDates.TabIndex = 1;
            this.btnScheduleDates.UseVisualStyleBackColor = false;
            this.btnScheduleDates.Click += new System.EventHandler(this.button2_Click);
            // 
            // dgvRequired
            // 
            this.dgvRequired.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequired.Location = new System.Drawing.Point(3, 84);
            this.dgvRequired.Name = "dgvRequired";
            this.dgvRequired.Size = new System.Drawing.Size(304, 262);
            this.dgvRequired.TabIndex = 0;
            this.dgvRequired.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tbpView
            // 
            this.tbpView.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tbpView.Controls.Add(this.groupBox2);
            this.tbpView.Controls.Add(this.dgvPersonnel);
            this.tbpView.ImageKey = "(none)";
            this.tbpView.Location = new System.Drawing.Point(4, 25);
            this.tbpView.Name = "tbpView";
            this.tbpView.Padding = new System.Windows.Forms.Padding(3);
            this.tbpView.Size = new System.Drawing.Size(742, 430);
            this.tbpView.TabIndex = 1;
            this.tbpView.Text = "View Personnel";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.txtPostal);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtSurbub);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnUpdate);
            this.groupBox2.Controls.Add(this.txtSalary);
            this.groupBox2.Controls.Add(this.txtSurname);
            this.groupBox2.Controls.Add(this.txtIDNumber);
            this.groupBox2.Controls.Add(this.txtContactNumber);
            this.groupBox2.Controls.Add(this.txtEmail);
            this.groupBox2.Controls.Add(this.txtHome);
            this.groupBox2.Controls.Add(this.txtName);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(20, 239);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(703, 178);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Update/Delete/Insert Employee";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label31.Location = new System.Drawing.Point(474, 126);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(64, 13);
            this.label31.TabIndex = 52;
            this.label31.Text = "Postal Code";
            // 
            // txtPostal
            // 
            this.txtPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPostal.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtPostal.Location = new System.Drawing.Point(477, 144);
            this.txtPostal.Multiline = true;
            this.txtPostal.Name = "txtPostal";
            this.txtPostal.Size = new System.Drawing.Size(73, 21);
            this.txtPostal.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label7.Location = new System.Drawing.Point(341, 126);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 50;
            this.label7.Text = "Surburb";
            // 
            // txtSurbub
            // 
            this.txtSurbub.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSurbub.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtSurbub.Location = new System.Drawing.Point(343, 144);
            this.txtSurbub.Name = "txtSurbub";
            this.txtSurbub.Size = new System.Drawing.Size(125, 20);
            this.txtSurbub.TabIndex = 49;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label9.Location = new System.Drawing.Point(17, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(84, 13);
            this.label9.TabIndex = 39;
            this.label9.Text = "Contact Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label8.Location = new System.Drawing.Point(17, 126);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 38;
            this.label8.Text = "Salary";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label5.Location = new System.Drawing.Point(17, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 35;
            this.label5.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(184, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 34;
            this.label4.Text = "Surname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(373, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 33;
            this.label3.Text = "ID Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(184, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 32;
            this.label2.Text = "Home Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label6.Location = new System.Drawing.Point(184, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Email Address";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdate.BackgroundImage")));
            this.btnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnUpdate.FlatAppearance.BorderSize = 0;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnUpdate.Location = new System.Drawing.Point(573, 62);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(112, 52);
            this.btnUpdate.TabIndex = 20;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click_3);
            // 
            // txtSalary
            // 
            this.txtSalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalary.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtSalary.Location = new System.Drawing.Point(20, 144);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(145, 20);
            this.txtSalary.TabIndex = 19;
            // 
            // txtSurname
            // 
            this.txtSurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSurname.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtSurname.Location = new System.Drawing.Point(187, 44);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(172, 20);
            this.txtSurname.TabIndex = 17;
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDNumber.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtIDNumber.Location = new System.Drawing.Point(376, 44);
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(172, 20);
            this.txtIDNumber.TabIndex = 16;
            // 
            // txtContactNumber
            // 
            this.txtContactNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactNumber.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtContactNumber.Location = new System.Drawing.Point(20, 94);
            this.txtContactNumber.Name = "txtContactNumber";
            this.txtContactNumber.Size = new System.Drawing.Size(145, 20);
            this.txtContactNumber.TabIndex = 15;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtEmail.Location = new System.Drawing.Point(187, 94);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(361, 20);
            this.txtEmail.TabIndex = 14;
            // 
            // txtHome
            // 
            this.txtHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHome.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtHome.Location = new System.Drawing.Point(187, 144);
            this.txtHome.Multiline = true;
            this.txtHome.Name = "txtHome";
            this.txtHome.Size = new System.Drawing.Size(148, 21);
            this.txtHome.TabIndex = 13;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtName.Location = new System.Drawing.Point(20, 44);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(145, 20);
            this.txtName.TabIndex = 12;
            // 
            // dgvPersonnel
            // 
            this.dgvPersonnel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPersonnel.Location = new System.Drawing.Point(20, 15);
            this.dgvPersonnel.Name = "dgvPersonnel";
            this.dgvPersonnel.Size = new System.Drawing.Size(703, 204);
            this.dgvPersonnel.TabIndex = 19;
            this.dgvPersonnel.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPersonnel_CellContentClick_3);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tbpView);
            this.tabControl1.Controls.Add(this.tbpInstal);
            this.tabControl1.Controls.Add(this.tbpMaintenace);
            this.tabControl1.Controls.Add(this.tbpAddPerson);
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(12, 88);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(750, 459);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 69;
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::SHSystem.Properties.Resources.blank_black_button_hi;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(611, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 39);
            this.button2.TabIndex = 71;
            this.button2.Text = "VIEW TECH IN TREE VIEW";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // frmTechSupport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.BackgroundImage = global::SHSystem.Properties.Resources._3__3157003_technology_network_loop_background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(772, 557);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmTechSupport";
            this.Text = "frmTechSupport";
            this.Load += new System.EventHandler(this.frmTechSupport_Load);
            this.tbpAddPerson.ResumeLayout(false);
            this.tbpAddPerson.PerformLayout();
            this.tbpMaintenace.ResumeLayout(false);
            this.tbpMaintenace.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFree)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReqMainten)).EndInit();
            this.tbpInstal.ResumeLayout(false);
            this.tbpInstal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFreePersonnel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequired)).EndInit();
            this.tbpView.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPersonnel)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage tbpAddPerson;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAddPost;
        private System.Windows.Forms.TextBox txtAddSurburb;
        private System.Windows.Forms.TextBox txtAddID;
        private System.Windows.Forms.TextBox txtAddSurname;
        private System.Windows.Forms.TextBox txtAddAddress;
        private System.Windows.Forms.TextBox txtAddCont;
        private System.Windows.Forms.TextBox txtAddEmail;
        private System.Windows.Forms.TextBox txtAddSalary;
        private System.Windows.Forms.TextBox txtAddName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TabPage tbpMaintenace;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtCost;
        private System.Windows.Forms.Button btnReqMaint;
        private System.Windows.Forms.Button btnSearchFree;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dtpD1;
        private System.Windows.Forms.DateTimePicker dtpD2;
        private System.Windows.Forms.DataGridView dgvFree;
        private System.Windows.Forms.Button btnSchedMaint;
        private System.Windows.Forms.Button btnSetDate;
        private System.Windows.Forms.DataGridView dgvReqMainten;
        private System.Windows.Forms.TabPage tbpInstal;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnFreePerson;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.DateTimePicker dtpDate2;
        private System.Windows.Forms.DateTimePicker dtpDate1;
        private System.Windows.Forms.Button btnViewRequired;
        private System.Windows.Forms.DataGridView dgvFreePersonnel;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnScheduleDates;
        private System.Windows.Forms.DataGridView dgvRequired;
        private System.Windows.Forms.TabPage tbpView;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtPostal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSurbub;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.TextBox txtContactNumber;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtHome;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DataGridView dgvPersonnel;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button button2;
    }
}