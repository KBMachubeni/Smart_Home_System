﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmRegisterUser : Form
    {

        public frmRegisterUser()
        {
            InitializeComponent();
        }

        public delegate void DelValid(string re, TextBox tb, PictureBox pb);
          DelValid del = new DelValid(ValidationClass.Regexp);
        private void RegisterUser_Load(object sender, EventArgs e)
        {

            List<Department> departmentlist = BLL.Department.DepartmentList();
            foreach (var item in departmentlist)
            {
                cmbDep.Items.Add(item.Name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //txtPassord.PasswordChar = '\0';
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
           // txtPassord.PasswordChar = '*';
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        { 

        }
        bool access = true;

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text.ToString();
            string password = txtPass.Text.ToString();
            string question = txtQuest.Text.ToString();
            string department = cmbDep.Text.ToString();
            string answer = txtAnswe.Text.ToString();
            string password2 = txtPassword2.Text;
            Users userInfo = new Users();

            BusinessLogic bl = new BusinessLogic();
            List<Users> Userlist = userInfo.UserLog();
            userInfo.Username = username;
            userInfo.Password = password;
            userInfo.SecurityQuestion = question;
            userInfo.SecurityAnswer = answer;

            if (txtUser.Text==""||txtPass.Text==""||txtQuest.Text=="")
            {
                MessageBox.Show("Please fill all fields", "Form not complete", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                return;
            }

            foreach (var item in Userlist)
            {
                if (item.Username.ToString() != username)
                {
                    access = true;
                    if (access == true)
                    {
                        if (username.Length <= 0)
                        {
                            MessageBox.Show("You need a Username to be registered", "Enter all fields", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            return;
                        }
                        else if (password.Length <= 0)
                        {
                            MessageBox.Show("You need a Password to be registered", "Enter all fields", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            return;
                        }
                        else if (password != password2)
                        {
                            MessageBox.Show("You need a passwords don't match to be registered", "Enter all fields", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            return;
                        }
                        else if (question.Length <= 0)
                        {
                            MessageBox.Show("You need a security question to be registered", "Enter all fields", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            return;
                        }
                        else if (answer.Length <= 0)
                        {
                            MessageBox.Show("You need a to supply answer for the question", "Enter all fields", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
                            return;
                        }

                        else if (cmbDep.Text.ToString() == "ProductManagement")
                        {
                            userInfo.DepartmentID = 1;
                            if (bl.NewUserAdd(userInfo) == true)
                            {
                                MessageBox.Show("User Added information Added");
                                frmSignIn signIn = new frmSignIn();
                                signIn.Show();
                                return;
                            }
                        }
                        else if (cmbDep.Text == "ClientMAnagement")
                        {
                            userInfo.DepartmentID = 2;
                            if (bl.NewUserAdd(userInfo) == true)
                            {
                                MessageBox.Show("User Added information Added");
                                frmSignIn signIn = new frmSignIn();
                                signIn.Show();
                                return;
                            }
                        }
                        else if (cmbDep.Text == "TechnicalSupport")
                        {
                            userInfo.DepartmentID = 3;
                            if (bl.NewUserAdd(userInfo) == true)
                            {
                                MessageBox.Show("User Added information Added");
                                frmSignIn signIn = new frmSignIn();
                                signIn.Show();
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Failed");
                        }
                        break;
                    }
                }
                if (access == false)
                {
                    MessageBox.Show("Username already taken", "Change Username", MessageBoxButtons.OK);
                }
            }
        }

        private void txtSecurityQuestion_OnTextChange(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmSignIn sign = new frmSignIn();
            sign.Show();
            this.Hide();
        }


        // following is 
        private void txtUser_TextChanged(object sender, EventArgs e)
        {
            del(@"^([\w]+)$", txtUser, pbUsername);
        }

        private void cmbDep_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)$", cmbDep, pbDepartment);
        }

        private void txtQuest_TextChanged(object sender, EventArgs e)
        {
            del(@"^([\w]+)$", txtQuest, pbSecurityQ);
        }

        private void txtAnswe_TextChanged(object sender, EventArgs e)
        {
            del(@"^([\w]+)$", txtAnswe, pbAnswer);
        }       
    }
}
