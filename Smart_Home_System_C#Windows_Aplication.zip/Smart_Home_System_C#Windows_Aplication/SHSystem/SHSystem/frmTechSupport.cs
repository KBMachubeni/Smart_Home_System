﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmTechSupport : Form
    {
        BindingSource bs = new BindingSource();
        BusinessLogic bl = new BusinessLogic();
        public frmTechSupport()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            bs.DataSource = Employee.SearchEmp(txtSearch.Text);
            dgvPersonnel.DataSource = bs;
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
           // bs.DataSource = Employee.EmpList();
            //dgvPersonnel.DataSource = bs;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Installation instal = new Installation();
                int current = dgvRequired.CurrentCell.RowIndex;
                //get installation ID

                int id = int.Parse(dgvRequired[1, current].Value.ToString());
          //     DateTime d1, d2;
                instal.StartDate =DateTime.Parse(dtpDate1.Value.ToString());
                instal.EndDate = DateTime.Parse(dtpDate2.Value.ToString());
                instal.InstallationID = id;

                
                //pass isntallation opject for update
                if (bl.InstalUpdate(instal) == true)
                    {
                   MessageBox.Show("Date Scheduled", "Schedule Succesful", MessageBoxButtons.OK);
                   bs.DataSource = Installation.Requiredinstallation(dtpDate1.Value, dtpDate2.Value);
                   dgvRequired.DataSource = bs;
                    this.dgvFreePersonnel.Visible = true;
                }
            }
            catch (Exception)
            {
                
                MessageBox.Show("Scheduling failed","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                Installation inst = new Installation();

                int currentEmp = dgvFreePersonnel.CurrentCell.RowIndex;
                emp.EmployeeID = int.Parse(dgvFreePersonnel[2, currentEmp].Value.ToString());

                int currentInst = dgvRequired.CurrentCell.RowIndex;
                inst.InstallationID = int.Parse(dgvRequired[1, currentInst].Value.ToString());
                //Passing Employee object for scheduling
                if (bl.ScheduleEmployee(emp, inst) == true)
                {
                    MessageBox.Show("Employee Schedules", "Schedule Succesful", MessageBoxButtons.OK);
                    dgvPersonnel.DataSource = bs;
                }
            }
            catch (Exception)
            {
                
                 MessageBox.Show("Scheduling failed","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }

        private void frmTechSupport_Load(object sender, EventArgs e)
        {
            this.dgvFreePersonnel.Visible = false;
            this.dgvFree.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvRequired.CurrentCell.RowIndex;
            DateTime d1 = DateTime.Parse(dgvRequired[3, current].Value.ToString());
            DateTime d2 = DateTime.Parse(dgvRequired[4, current].Value.ToString());
           // idd.Text=dgvRequired[2, current].Value.ToString();

            //Selecting employee based on dates
            BindingSource s = new BindingSource();
            s.DataSource = Employee.EmpList(d1, d2);
            dgvFreePersonnel.DataSource = s;
            this.dgvFreePersonnel.Columns[0].Visible = false;
            this.dgvFreePersonnel.Columns[1].Visible = false;
            this.dgvFreePersonnel.Columns[2].Visible = false;
            this.dgvFreePersonnel.Columns[3].Visible = false;
            this.dgvFreePersonnel.Columns[4].Visible = false;
            this.dgvFreePersonnel.Columns[9].Visible = false;
            this.dgvFreePersonnel.Columns[10].Visible = false;
            this.dgvFreePersonnel.Columns[11].Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Installation isnt=new Installation();
            bs.DataSource = Installation.Requiredinstallation(isnt.defaultdate,isnt.defaultdate);
            dgvRequired.DataSource = bs;
            //this.dgvRequired.Columns[0].Visible = false;
            //this.dgvRequired.Columns[1].Visible = false;
        }

        private void dgvFreePersonnel_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvFreePersonnel.CurrentCell.RowIndex;
            //label22.Text =dgvFreePersonnel[3, current].Value.ToString();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            try
            {
                BindingSource s = new BindingSource();
                DateTime date1 = DateTime.Parse(dtpDate1.Value.ToString());
                DateTime date2 = DateTime.Parse(dtpDate2.Value.ToString());
                int days = (dtpDate2.Value - dtpDate1.Value).Days;
                if (days <= 0)
                {
                    MessageBox.Show("Date difference =" + days + " days can't be a negative number", "Invalid date difference", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    s.DataSource = Employee.EmpList(date1, date2);
                    dgvFreePersonnel.DataSource = s;
                    this.dgvFreePersonnel.Visible = true;
                    this.dgvFreePersonnel.Columns[0].Visible = false;
                    this.dgvFreePersonnel.Columns[1].Visible = false;
                    this.dgvFreePersonnel.Columns[2].Visible = false;
                    this.dgvFreePersonnel.Columns[3].Visible = false;
                    this.dgvFreePersonnel.Columns[4].Visible = false;
                    this.dgvFreePersonnel.Columns[9].Visible = false;
                    this.dgvFreePersonnel.Columns[10].Visible = false;
                    this.dgvFreePersonnel.Columns[11].Visible = false;
                }
                
            }
            catch (Exception)
            {

                MessageBox.Show("Please ensure you selected dates", "Error selecting dates", MessageBoxButtons.OK);
            }
            
        }

        private void dgvPersonnel_CellContentClick_3(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvPersonnel.CurrentCell.RowIndex;
            txtName.Text = dgvPersonnel[4, current].Value.ToString();
            txtSurname.Text = dgvPersonnel[5, current].Value.ToString();
            txtIDNumber.Text = dgvPersonnel[6, current].Value.ToString();
            txtContactNumber.Text = dgvPersonnel[7, current].Value.ToString();
            txtEmail.Text = dgvPersonnel[8, current].Value.ToString();
            txtSalary.Text = dgvPersonnel[3, current].Value.ToString();
            txtHome.Text = dgvPersonnel[9, current].Value.ToString();
            txtSurbub.Text = dgvPersonnel[10, current].Value.ToString();
            txtPostal.Text = dgvPersonnel[11, current].Value.ToString();
        }

        private void btnUpdate_Click_3(object sender, EventArgs e)
        {
            try
            {
                int current = dgvPersonnel.CurrentCell.RowIndex;
                Employee emp = new Employee();
                int id = int.Parse(dgvPersonnel[2, current].Value.ToString());
                emp.EmployeeID = id;
                emp.Name = txtName.Text.ToString();
                emp.surname = txtSurname.Text.ToString();
                emp.idNumber = txtIDNumber.Text.ToString();
                emp.ContactNumber = txtContactNumber.Text.ToString();
                emp.Email = txtEmail.Text.ToString();

                BLL.BusinessLogic bl = new BusinessLogic();

                if (bl.EmployeeUpdate(emp) == true)
                {
                    MessageBox.Show("Personnel information updated","Operation Succesfful",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Update Failed try again","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            
        }

        private void btnReqMaint_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Employee emp = new Employee();
            emp.Name = txtAddName.Text;
            emp.surname = txtAddSurname.Text.ToString();
            emp.idNumber = txtAddID.Text.ToString();
            emp.ContactNumber = txtAddCont.Text.ToString();
            emp.Email = txtAddEmail.Text.ToString();
            emp.Salary = double.Parse(txtAddSalary.Text.ToString());
            emp.Address = txtAddAddress.Text.ToString();
            emp.Surburb = txtAddSurburb.Text.ToString();
            emp.PostalCode = txtAddPost.Text.ToString();

            if (bl.EmployeeAdd(emp) == true)
            {
                MessageBox.Show("Employee Added");
                bs.DataSource = Employee.SearchEmp(txtAddID.Text);
                dgvPersonnel.DataSource = bs;
            }
            else
            {
                MessageBox.Show("Failed");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Maintenance maintenance = new Maintenance();
            bs.DataSource = maintenance.RequiredinMaintenace(maintenance.defaultdate, maintenance.defaultdate);
            dgvReqMainten.DataSource = bs;
        }

        private void btnSearchFree_Click(object sender, EventArgs e)
        {
            BindingSource s = new BindingSource();
            DateTime date1 = DateTime.Parse(dtpDate1.Value.ToString());
            DateTime date2 = DateTime.Parse(dtpDate2.Value.ToString());

            int days = (dtpD1.Value - dtpD2.Value).Days;
            if (days <= 0)
            {
                MessageBox.Show("Date difference =" + days + " days can't be a negative number", "Invalid date difference", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                s.DataSource = Employee.FreeEmpl(date1, date2);
                dgvFree.DataSource = s;
                this.dgvFree.Visible = true;
                this.dgvFree.Columns[0].Visible = false;
                this.dgvFree.Columns[1].Visible = false;
                this.dgvFree.Columns[2].Visible = false;
                this.dgvFree.Columns[3].Visible = false;
                this.dgvFree.Columns[4].Visible = false;
                this.dgvFree.Columns[9].Visible = false;
                this.dgvFree.Columns[10].Visible = false;
                this.dgvFree.Columns[11].Visible = false;
            }
            
        }

        private void btnSetDate_Click(object sender, EventArgs e)
        {
            try
            {
                Maintenance MaintUpdate = new Maintenance();
                int current = dgvReqMainten.CurrentCell.RowIndex;
                int id = int.Parse(dgvReqMainten[0, current].Value.ToString());
         //       DateTime d1, d2;
                MaintUpdate.StartDate = DateTime.Parse(dtpD1.Value.ToString());
                MaintUpdate.EndDate = DateTime.Parse(dtpD2.Value.ToString());
                MaintUpdate.MaintenanceID = id;
                MaintUpdate.Cost = double.Parse(txtCost.Text.ToString());
                if (txtCost.Text=="")
                {
                    MessageBox.Show("Please enter maintenance cost", "Cost not set", MessageBoxButtons.OK);
                }
               
                else if (bl.ScheduleMaintenance(MaintUpdate) == true)
                    {
                     MessageBox.Show("Date Scheduled", "Schedule Succesful", MessageBoxButtons.OK);
                     bs.DataSource = MaintUpdate.RequiredinMaintenace(dtpDate1.Value, dtpDate2.Value);
                     dgvRequired.DataSource = bs;
                     this.dgvFreePersonnel.Visible = true;
                   }
               }
            catch (Exception)
            {
                
                MessageBox.Show("Scheduling failed try again","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void dgvReqMainten_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvReqMainten.CurrentCell.RowIndex;
            DateTime d1 = DateTime.Parse(dgvReqMainten[5, current].Value.ToString());
            DateTime d2 = DateTime.Parse(dgvReqMainten[6, current].Value.ToString());
            //idd.Text = dgvReqMainten[2, current].Value.ToString();

            BindingSource s = new BindingSource();
            s.DataSource = Employee.FreeEmpl(d1, d2);
            dgvFree.DataSource = s;
            this.dgvFree.Columns[0].Visible = false;
            this.dgvFree.Columns[1].Visible = false;
            this.dgvFree.Columns[2].Visible = false;
            this.dgvFree.Columns[3].Visible = false;
            this.dgvFree.Columns[4].Visible = false;
            this.dgvFree.Columns[9].Visible = false;
            this.dgvFree.Columns[10].Visible = false;
            this.dgvFree.Columns[11].Visible = false;
        }

        private void btnSchedMaint_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                Maintenance Main = new Maintenance();

                int currentEmp = dgvFree.CurrentCell.RowIndex;
                emp.EmployeeID = int.Parse(dgvFree[2, currentEmp].Value.ToString());

                int currentInst = dgvReqMainten.CurrentCell.RowIndex;
                Main.MaintenanceID = int.Parse(dgvReqMainten[0, currentInst].Value.ToString());
                if (bl.ScheduleEmployeeMaint(emp, Main) == true)
                {
                    MessageBox.Show("Employee Schedules", "Schedule Succesful", MessageBoxButtons.OK);
                    dgvPersonnel.DataSource = bs;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Scheduling failed", "Operation Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void btnSave_Click_2(object sender, EventArgs e)
        {
            try
            {
                Employee em = new Employee();
                em.Name = txtAddName.Text;
                em.Surname = txtAddSurname.Text;
                em.Surburb = txtAddSurburb.Text;
                em.Salary = double.Parse(txtAddSalary.Text);
                em.PostalCode = txtAddPost.Text;
                em.Email = txtAddEmail.Text;
                em.ContactNumber = txtAddCont.Text;
                    txtAddAddress.Clear();
            txtAddCont.Clear();
            txtAddEmail.Clear();
            txtAddID.Clear();
            txtAddName.Clear();
            txtAddPost.Clear();
            txtAddSalary.Clear();
            txtAddSurburb.Clear();
            txtAddSurname.Clear();
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtAddAddress.Clear();
            txtAddCont.Clear();
            txtAddEmail.Clear();
            txtAddID.Clear();
            txtAddName.Clear();
            txtAddPost.Clear();
            txtAddSalary.Clear();
            txtAddSurburb.Clear();
            txtAddSurname.Clear();
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            Main M = new Main();
            M.Show();
            this.Close();
        }

        private void tbpAddPerson_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            TreeTest tt = new TreeTest();
            tt.Show();
            this.Hide();
        }
    }
}
