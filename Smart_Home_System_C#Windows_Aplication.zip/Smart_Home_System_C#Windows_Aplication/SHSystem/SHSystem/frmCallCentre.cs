﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using BLL;

namespace SHSystem
{
    public partial class frmCallCentre : Form
    {
        public frmCallCentre()
        {
            InitializeComponent();
        }
        Stopwatch stopwatch = new Stopwatch();
        private void btnDial_Click(object sender, EventArgs e)
        {
            // start call
            stopwatch.Start();
        }

        private void btnHangup_Click(object sender, EventArgs e)
        {
            // hang up the call
            stopwatch.Stop();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // save the information gatherred from the client
            Call call = new Call();
            BusinessLogic bl = new BusinessLogic();
            call.Caller = txtCaller.Text;
            call.Descrption = txtDescription.Text;
            call.PhoneNumber = txtPhoneNumber.Text;
            call.CallDate = DateTime.Today;
            call.Duration = stopwatch.Elapsed.ToString();
            if (bl.LogCall(call) == true)
            {
                MessageBox.Show("Call logged succesfully", "Successful", MessageBoxButtons.OK);
            }
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Main m = new Main();
            m.Show();
            this.Hide();
        }

        private void dgvClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // after entering their id then it will be shown in the data grid view if not the row will be empty
            int current = dgvClient.CurrentCell.RowIndex;
          
           txtCaller.Text = dgvClient[4, current].Value.ToString();
            txtPhoneNumber.Text= dgvClient[5, current].Value.ToString();
        

           
        }

        BindingSource bs1 = new BindingSource();

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //search if the client calling does exist
            if (txtSearch.Text == " ")
            {
                MessageBox.Show("Please enter an ID to search with", "ID needed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                bs1.DataSource = Client.SearchClient(txtSearch.Text.ToString());
                dgvClient.DataSource = bs1;
                this.dgvClient.Columns[1].Visible = false;
               
            }
        }

        private void frmCallCentre_Load(object sender, EventArgs e)
        {

        }
    }
}
