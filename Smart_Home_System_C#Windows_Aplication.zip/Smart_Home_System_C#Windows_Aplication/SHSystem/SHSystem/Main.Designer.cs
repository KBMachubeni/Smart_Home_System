﻿namespace SHSystem
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCallCenter = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnTech = new System.Windows.Forms.Button();
            this.btnProductManagement = new System.Windows.Forms.Button();
            this.btnCLM = new System.Windows.Forms.Button();
            this.txtLuser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(40, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 16);
            this.label1.TabIndex = 40;
            this.label1.Text = "CLIENT MANGEMNET";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Perpetua Titling MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(229, 280);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 16);
            this.label2.TabIndex = 41;
            this.label2.Text = "PRODUCT MANGEMNET";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Perpetua Titling MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(444, 280);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 16);
            this.label3.TabIndex = 42;
            this.label3.Text = "TECHNICAL SUPPORT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Perpetua Titling MT", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(665, 280);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 16);
            this.label4.TabIndex = 43;
            this.label4.Text = "CALL CENTER";
            // 
            // btnCallCenter
            // 
            this.btnCallCenter.BackColor = System.Drawing.Color.Transparent;
            this.btnCallCenter.BackgroundImage = global::SHSystem.Properties.Resources.telefoon_icoon_2;
            this.btnCallCenter.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCallCenter.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnCallCenter.FlatAppearance.BorderSize = 0;
            this.btnCallCenter.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCallCenter.Location = new System.Drawing.Point(647, 92);
            this.btnCallCenter.Name = "btnCallCenter";
            this.btnCallCenter.Size = new System.Drawing.Size(158, 174);
            this.btnCallCenter.TabIndex = 44;
            this.btnCallCenter.UseVisualStyleBackColor = false;
            this.btnCallCenter.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::SHSystem.Properties.Resources.GrayRoundedButton;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(22, 324);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 40);
            this.button1.TabIndex = 39;
            this.button1.Text = "Register User";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnBack.BackgroundImage = global::SHSystem.Properties.Resources.logout_button_md;
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(744, 0);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(70, 59);
            this.btnBack.TabIndex = 38;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnTech
            // 
            this.btnTech.BackColor = System.Drawing.Color.Transparent;
            this.btnTech.BackgroundImage = global::SHSystem.Properties.Resources.tick_icon_73037;
            this.btnTech.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTech.FlatAppearance.BorderSize = 0;
            this.btnTech.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTech.Location = new System.Drawing.Point(449, 91);
            this.btnTech.Name = "btnTech";
            this.btnTech.Size = new System.Drawing.Size(169, 175);
            this.btnTech.TabIndex = 3;
            this.btnTech.UseVisualStyleBackColor = false;
            this.btnTech.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnProductManagement
            // 
            this.btnProductManagement.BackColor = System.Drawing.Color.Transparent;
            this.btnProductManagement.BackgroundImage = global::SHSystem.Properties.Resources.Frontend_Checkout;
            this.btnProductManagement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnProductManagement.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProductManagement.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProductManagement.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductManagement.Location = new System.Drawing.Point(232, 91);
            this.btnProductManagement.Name = "btnProductManagement";
            this.btnProductManagement.Size = new System.Drawing.Size(184, 175);
            this.btnProductManagement.TabIndex = 2;
            this.btnProductManagement.UseVisualStyleBackColor = false;
            this.btnProductManagement.Click += new System.EventHandler(this.btnProductManagement_Click);
            // 
            // btnCLM
            // 
            this.btnCLM.BackColor = System.Drawing.Color.Transparent;
            this.btnCLM.BackgroundImage = global::SHSystem.Properties.Resources.user_male2_512;
            this.btnCLM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCLM.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCLM.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCLM.Location = new System.Drawing.Point(22, 92);
            this.btnCLM.Name = "btnCLM";
            this.btnCLM.Size = new System.Drawing.Size(184, 175);
            this.btnCLM.TabIndex = 1;
            this.btnCLM.UseVisualStyleBackColor = false;
            this.btnCLM.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtLuser
            // 
            this.txtLuser.AutoSize = true;
            this.txtLuser.Location = new System.Drawing.Point(627, 24);
            this.txtLuser.Name = "txtLuser";
            this.txtLuser.Size = new System.Drawing.Size(0, 13);
            this.txtLuser.TabIndex = 45;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::SHSystem.Properties.Resources._3__3157003_technology_network_loop_background;
            this.ClientSize = new System.Drawing.Size(817, 376);
            this.Controls.Add(this.txtLuser);
            this.Controls.Add(this.btnCallCenter);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnTech);
            this.Controls.Add(this.btnProductManagement);
            this.Controls.Add(this.btnCLM);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCLM;
        private System.Windows.Forms.Button btnProductManagement;
        private System.Windows.Forms.Button btnTech;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCallCenter;
        private System.Windows.Forms.Label txtLuser;
    }
}