﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class TreeTest : Form
    {
        public TreeTest()
        {
            InitializeComponent();
        }
        StoredProcedures sp = new StoredProcedures();

        private void TreeTest_Load(object sender, EventArgs e)
        {
            DataTable dt = sp.GetPersonnelData();
            this.PopulateTreeView(dt, 0, null);
            
        }

        public void PopulateTreeView(DataTable dtParent, int ParentId, TreeNode treeNode)
        {
            foreach (DataRow row in dtParent.Rows)
            {
                TreeNode child = new TreeNode
                {
                    Text = row["EmployeelID"].ToString()
                    
                };

                if (ParentId == 0)
                {
                    treeView1.Nodes.Add(child);
                    DataTable dtChild = sp.GetPersonnelSchedule(child.Text);
                    PopulateTreeView(dtChild, int.Parse(child.Text), child);
                }
            }
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmTechSupport tss = new frmTechSupport();
            tss.Show();
            this.Hide();
        }  
    }
}
