﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class Clients : Form
    {
        BindingSource bs1 = new BindingSource();
        BindingSource bs2 = new BindingSource();
        BindingSource bs3 = new BindingSource();
        BindingSource bs4 = new BindingSource();
      

        
        BusinessLogic bl = new BusinessLogic();
        Client cl = new Client();
        Contract contract = new Contract();
        Installation inst = new Installation();
        Maintenance maint=new Maintenance();
       Call call= new Call();


      
        public Clients(string user)
        {
            InitializeComponent();
            lblUser.Text = user;
            dateTimePicker1.Value = DateTime.Today;
        }

        public Clients()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
        }

        public void HideContractColumns()
        {
            this.dgvContract.Columns[0].Visible=false;
            this.dgvContract.Columns[4].Visible = false;
            this.dgvContract.Columns[5].Visible = false;
            this.dgvContract.Columns[6].Visible = false;
            this.dgvContract.Columns[7].Visible = false;
            this.dgvContract.Columns[9].Visible = false;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        //method for searching the client 
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text==" ")
            {
                MessageBox.Show("Please enter an ID to search with", "ID needed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                bs1.DataSource = Client.SearchClient(txtSearch.Text.ToString());
                dgvClient.DataSource = bs1;
                this.dgvClient.Columns[1].Visible = false;
                dgvContract.DataSource = false;
                dataGridView1.DataSource = false;
            }
            
        }

        private void dgvClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvClient.CurrentCell.RowIndex;
            txtName.Text = dgvClient[2, current].Value.ToString();
            txtSurname.Text = dgvClient[3, current].Value.ToString();
            txtIDNumber.Text = dgvClient[4, current].Value.ToString();
            txtConNumber.Text = dgvClient[5, current].Value.ToString();
            txtEmail.Text = dgvClient[6, current].Value.ToString();
            txtAddress.Text = dgvClient[7, current].Value.ToString();
            txtSurbub.Text = dgvClient[8, current].Value.ToString();
            txtPostal.Text= dgvClient[9, current].Value.ToString();
            int Clieid = int.Parse(dgvClient[0, current].Value.ToString());
            
            dataGridView1.DataSource = false;
            btnAddCont.Visible = true;
            if (Clieid >= 0)
            {
                bs2.DataSource = Contract.SearchContract(Clieid);
                dgvContract.DataSource = bs2;
                HideContractColumns();
            }
            else
            {
                dgvContract.DataSource = false;
            }

            cmbContractType.Text = string.Empty;
            cmbService.Text = string.Empty;
            cmbStatus.Text = string.Empty; 
            
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        { 
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int current = dataGridView1.CurrentCell.RowIndex;
                int maintenaceID = int.Parse(dataGridView1[0, current].Value.ToString());
                maint.MaintenanceID = maintenaceID;
                maint.Description = txtDiscrpt.Text.ToString();
                if (bl.MaintUpdate(maint) == true)
                {
                    MessageBox.Show("information updated");
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Failed to Add Maintenance","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                int current = dgvClient.CurrentCell.RowIndex;
                int id = int.Parse(dgvClient[0, current].Value.ToString());
                Client cl = new Client();
                cl.ClientID = id;
                cl.Name = txtName.Text;
                cl.Surname = txtSurname.Text;
                cl.idNumber = txtIDNumber.Text;
                cl.ContactNumber = txtConNumber.Text;
                cl.Email = txtEmail.Text;
                cl.Surburb = txtSurbub.Text;
                cl.PostalCode = txtPostal.Text;
                cl.Address = txtAddress.Text;
                this.dgvClient.Columns[1].Visible = false;
                dgvContract.DataSource = false;
                dataGridView1.DataSource = false;
                if (bl.ClientUpdate(cl) == true)
                {
                    MessageBox.Show("Client information updated");
                    bs1.DataSource = Client.SearchClient(txtSearch.Text.ToString());
                    dgvClient.DataSource = bs1;
                    this.dgvClient.Columns[1].Visible = false;
                    dgvContract.DataSource = false;
                    dataGridView1.DataSource = false;
                }
                else
                {
                    throw new MyException("Update Failed");
                }
            }
            catch 
            {

                MessageBox.Show("Update Failed Try again", "Operation failed", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }
            
        }

        private void btnAll_Click(object sender, EventArgs e)
        {
           
        }

        private void tbpContract_Click(object sender, EventArgs e)
        { 

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dataGridView1.CurrentCell.RowIndex;
            int MaintenaceID=int.Parse(dataGridView1[0, current].Value.ToString());
            txtDiscrpt.Text = dataGridView1[1, current].Value.ToString();
            //lblID.Text = dataGridView1[0, current].Value.ToString();
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
           
            
        }

        private void BindData(int id)
        {
            Option opt = new Option();
            BindingSource bs4 = new BindingSource();
            bs4.DataSource = opt.ProductOption(id);
            lstOption.DataSource = bs4;
            lblCost.DataBindings.Clear();
            lstOption.DisplayMember = "OptionDisplay";
            lblMonthfee.DataBindings.Clear();
            lblMonthfee.DataBindings.Add(new Binding("Text", bs4, "MonthFee"));
        }

        private void BindAll()
        {
            Option opt = new Option();
            BindingSource bs4 = new BindingSource();
            bs4.DataSource = opt.OptiontList();
            lstOption.DataSource = bs4;
            lblCost.DataBindings.Clear();
            lstOption.DisplayMember = "OptionDisplay";
            lblCost.DataBindings.Add(new Binding("Text", bs4, "Cost"));
            lblMonthfee.DataBindings.Clear();
            lblMonthfee.DataBindings.Add(new Binding("Text", bs4, "MonthFee"));
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //bool current1 = Convert.ToBoolean(dataGridView2.CurrentCell.RowIndex);
            int current = dgvContract.CurrentCell.RowIndex;
            cmbStatus.Text = dgvContract[8, current].Value.ToString();
            cmbService.Text = dgvContract[5, current].Value.ToString();
            cmbContractType.Text = dgvContract[7, current].Value.ToString();
            int IptID = int.Parse(dgvContract[4, current].Value.ToString());
            lblOptID.Text = dgvContract[0, current].Value.ToString();
            int Maintid = int.Parse(dgvContract[0, current].Value.ToString());
            bs3.DataSource = maint.SelectMaintenace(Maintid);
            dataGridView1.DataSource = bs3;

            this.dataGridView1.Columns[3].Visible = false;
            BindData(IptID);
            
            btnUpdateCont.Visible = true;
            btnAddCont.Visible = true;
        }

        private void Clients_Load(object sender, EventArgs e)
        {
            string[] ContractType = new string[] {"1.A", "2.B", "3.C","4.D" };
            string[] Service = new string[] { "1.VVIP", "2.VIP", "3.IP" };
            string[] Status = new string[] { "Active", "Not Active" };
            for (int i = 0; i < 4; i++)
            {
                cmbContractType.Items.Add(ContractType[i]);
                Conttype.Items.Add(ContractType[i]);
            }
            for (int i = 0; i < 3; i++)
            {
                cmbService.Items.Add(Service[i]);
                level.Items.Add(Service[i]);
            }
            for (int i = 0; i < 2; i++)
            {
                cmbStatus.Items.Add(Status[i]);
                status.Items.Add(Status[i]);
            }

            btnAdd.Visible = false;
            btnUpdateCont.Visible = false;
            btnAddCont.Visible = false;

            BindingSource b5 = new BindingSource();
            Option op=new Option();
            b5.DataSource = op.OptiontList();
            dgvOptions.DataSource = b5;
            dgvOptions.Columns[0].Visible = false;
            dgvOptions.Columns[2].Visible = false;
            dgvOptions.Columns[4].Visible = false;
            dgvOptions.Columns[6].Visible = false;

               //datatable containg the calls made by clients
            DataTable dt = call.CallRetrive();
            
            //making the databale the datasource of  binding source 4
            bs4.DataSource = dt;

            //when form loads all calls made by clients will be retrieved
            dgvCalls.DataSource = bs4;

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //butteon clears all the text boxes
            MessageBox.Show("Are you sure?", "Warning", MessageBoxButtons.OKCancel);
            txtID.Clear();
            txtAddName.Clear();
            txtAddNumber.Clear();
            txtAddPayment.Clear();
            txtAddCode.Clear();
            txtAddSurburb.Clear();
            txtAddSname.Clear();
            txtAddEmail.Clear();
            txtAddHome.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                //method makes the client a sale and adds their information to the database
                cl.Name = txtAddName.Text.ToString();
                cl.Surname = txtAddSname.Text.ToString();
                cl.IdNumber = txtID.Text.ToString();
                cl.ContactNumber = txtAddNumber.Text.ToString();
                cl.Email = txtAddEmail.Text.ToString();
                cl.Address = txtAddHome.Text.ToString();
                cl.Surburb = txtAddSurburb.Text.ToString();
                cl.PostalCode = txtAddCode.Text.ToString();

                int current = dgvOptions.CurrentCell.RowIndex;
                int OptionID=int.Parse(dgvOptions[0, current].Value.ToString());

                Contract cnt=new Contract();
                double paymet=double.Parse(txtAddPayment.Text.ToString()); 
                string TypeID = Conttype.Text.ToString().Substring(0, 1);
                string levelID = level.Text.ToString().Substring(0, 1);

                cnt.SignedDate=DateTime.Parse(DateTime.Now.ToString());
                cnt.PaymentMade = paymet;
                cnt.OptionID=OptionID;
                cnt.ServiceLevelID=int.Parse(TypeID);
                cnt.ContactTypeID=int.Parse(levelID);
                cnt.ContractStatus=cmbStatus.Text.ToString();
                if (txtAddName.Text==""||txtID.Text==""||txtAddNumber.Text==""||txtAddPayment.Text=="")
                {
                    MessageBox.Show("Please fill all fields");
                    return;
                }

                if (bl.AddNew(cl,cnt)==true && bl.AddContract(cnt))
              {
                MessageBox.Show("Client information Added");
                txtID.Clear();
                txtAddName.Clear();
                txtAddNumber.Clear();
                txtAddPayment.Clear();
                txtAddCode.Clear();
                txtAddSurburb.Clear();
                txtAddSname.Clear();
                txtAddEmail.Clear();
                txtAddHome.Clear();
               }
              }
            catch (Exception)
            {
                
                MessageBox.Show("Failed to make sale please try again","Operation Failed",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void tbpAdd_Click(object sender, EventArgs e)
        {

        }

        private void dgvOptions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvOptions.CurrentCell.RowIndex;
            lblOptionCost.Text = dgvOptions[3, current].Value.ToString();
        }

        private void btnAddMaint_Click(object sender, EventArgs e)
        {
            try
            {
              maint.Description = txtDiscrpt.Text.ToString();
              int current = dgvContract.CurrentCell.RowIndex;
              maint.ContractID =int.Parse(dgvContract[0, current].Value.ToString());
              if (bl.AddMaintenace(maint)==true)
               {
                MessageBox.Show("Maintenace Set", "Successful", MessageBoxButtons.OK);
               }
            }
            catch (Exception)
            { 
                MessageBox.Show("Failed", "Fail", MessageBoxButtons.OK);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void lstOption_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdateInfo_Click(object sender, EventArgs e)
        {
            //button is for updating the contract of a client
            Contract Contr = new Contract();
            int current = dgvContract.CurrentCell.RowIndex;
            int ContractID = int.Parse(dgvContract[0, current].Value.ToString());
            string Contstatus = dgvContract[8, current].Value.ToString();
            Contr.ContractID = ContractID;
            Contr.ContractStatus = cmbStatus.Text.ToString();
            string Type = cmbContractType.Text.ToString().Substring(0, 1);
            string level = cmbService.Text.ToString().Substring(0, 1);
            Contr.ContactTypeID = int.Parse(Type);
            Contr.ServiceLevelID = int.Parse(level);
            BLL.BusinessLogic bl = new BusinessLogic();


            if (Contstatus == "Active" && cmbStatus.Text.ToString() == Contstatus)
            {
                MessageBox.Show("Can't have two ative Contracts", "Active Contract Exists", MessageBoxButtons.RetryCancel);
            }

            else if (bl.ContractUpdate(Contr) == true)
            {
                MessageBox.Show("information updated");
            }
            else
            {
                MessageBox.Show("Failed");
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            BindAll();
            btnAdd.Visible = true;
            btnAddCont.Visible = false;
        }

        private void btnSaveInfo_Click(object sender, EventArgs e)
        {
            try
            {
                BLL.BusinessLogic bl = new BusinessLogic();
                Contract cnt = new Contract();
                Random r = new Random();
                int id = r.Next(100000, 999999);
                cnt.Identifier = id.ToString();
                double paymet = double.Parse(txtPay.Text.ToString());
                cnt.PaymentMade = paymet;

                cnt.SignedDate = DateTime.Parse(DateTime.Now.ToString());

                int currentCLient = dgvClient.CurrentCell.RowIndex;
                cnt.ClientID = int.Parse(dgvClient[0, currentCLient].Value.ToString());
                

                //int current = dgvContract.CurrentCell.RowIndex;
                //string Contstatus = dgvContract[8, current].Value.ToString();

                cnt.ServiceLevelID = int.Parse(cmbService.Text.Substring(0, 1).ToString());
                cnt.ContactTypeID = int.Parse(cmbContractType.Text.Substring(0, 1).ToString());
                cnt.ContractStatus = cmbStatus.Text.ToString();
                cnt.OptionID = int.Parse(lblOption.Text.ToString()); 

                //if (Contstatus == "Active" && cmbStatus.Text.ToString() == Contstatus)
                //{
                //    MessageBox.Show("Can't have two ative Contracts", "Active Contract Exists", MessageBoxButtons.RetryCancel);
                //}

                if (paymet < double.Parse(lblCost.Text.ToString()) || paymet > double.Parse(lblCost.Text.ToString()))
                {
                    MessageBox.Show("Enter the correct Payment", "InsufficientFunds", MessageBoxButtons.RetryCancel);
                }
                else
                {
                    if (bl.AddContract(cnt) == true)
                    {
                        MessageBox.Show("Contract information Added", "Succeful", MessageBoxButtons.OK);
                        Clients clientfrm = new Clients();
                        clientfrm.Show();
                        btnAddCont.Visible = true;
                        btnAdd.Visible = false;
                    }
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Entry failed try again", "Failed", MessageBoxButtons.RetryCancel);
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            bs1.DataSource = cl.ClientList();
            dgvClient.DataSource = bs1;
            this.dgvClient.Columns[1].Visible = false;
            dgvContract.DataSource = false;
            dataGridView1.DataSource = false;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            frmSignIn sign = new frmSignIn();
            sign.Show();
            this.Close();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            frmAddClient add = new frmAddClient();
            add.Show();
            this.Close();
        }

        private void dgvCalls_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
