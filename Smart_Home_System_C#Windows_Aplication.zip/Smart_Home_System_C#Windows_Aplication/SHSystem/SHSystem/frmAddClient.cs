﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmAddClient : Form
    {
        public frmAddClient()
        {
            InitializeComponent();
        }


        private void MakeSale_Load(object sender, EventArgs e)
        {
            
        }
        private void label11_Click(object sender, EventArgs e)
        {

        }

        /// add client to the database even when they are not purchasing anything
        private void button1_Click(object sender, EventArgs e)
        {
            BLL.BusinessLogic bl = new BusinessLogic();
            Client cl = new Client();
            Random r = new Random();
          var array=  Enumerable.Range(18, 60).ToArray();
            int id=int.Parse(r.Next(100000, 999999).ToString());
            cl.Name = txtName.Text.ToString();
            cl.Surname = txtSurname.Text.ToString();
            cl.IdNumber = txtID.Text.ToString();
            cl.Address = txtHome.Text.ToString();
            cl.ContactNumber = txtNumber.Text.ToString();
            cl.Email = txtEmail.Text.ToString();
            cl.Surburb = txtSurburb.Text.ToString();
            cl.PostalCode = txtCode.Text.ToString();
            cl.ClientIdentifier = id.ToString();
            
           
            if (bl.AddClient(cl) == true)
            {
                MessageBox.Show("Client information Added");
                Clients clientfrm = new Clients();
                clientfrm.Show();
            }
            //cl.PostalCode=txt
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            
            txtName.Text = " ";
            txtSurname.Text = " ";
            txtID.Text = " ";
            txtHome.Text = " ";
            txtNumber.Text = " ";
          txtSurburb.Text = " ";
          txtCode.Text = " ";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Clients c = new Clients();
            c.Show();
            this.Hide();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([a-z-A-Z]+)$", txtName, pbName);
        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([0-9]{13})$", txtID, pbId);
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)@([\w]+)\.([\w]+)$", txtEmail, pbEmail);
        }

        private void txtHome_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)$", txtHome, pbAddress);
        }

        private void txtCode_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)$", txtCode, pbCode);
        }

        private void txtSurname_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([a-z-A-Z]+)$", txtSurname, pbSurname);
        }

        private void txtNumber_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^(0)([0-9]{9})$", txtNumber, pbNumber);
        }

        private void txtSurburb_TextChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)$", txtSurburb, pbSurburb);
        }

        private void cmbAge_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidationClass.Regexp(@"^([\w]+)$", cmbAge, pbAge);

        }
    }
}
