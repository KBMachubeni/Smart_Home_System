﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Windows.Forms;


namespace SHSystem
{
     class dbConnect
    {
        private SqlDataAdapter myAdapter;
        private SqlConnection conn;
        SqlCommand myCommand;
        


        public dbConnect()
        {
            myAdapter = new SqlDataAdapter();
            conn = new SqlConnection("Data Source=DESKTOP-QTGKLKB;Initial Catalog=SHSDB;Integrated Security=True");
        }

        public void LogIn(string username, string Password)
        {
            myAdapter = new SqlDataAdapter("SELECT COUNT(*) FROM tblUsers WHERE UserName='" + username + "'AND UserPassword='" + Password + "'",conn);
            DataTable dt = new DataTable();
            myAdapter.Fill(dt);
            if (dt.Rows[0][0].ToString() != "1")
            {
                MessageBox.Show("Please make sure your credentilas are correct");
            }
            else
            {
                Main m = new Main();
                m.Show();
            }
        }
         //Delete 
       //  public void DeleteCustomerDB(int custid)
        //{
          //  DataSet ds = new DataSet();
            //string sql = "Delete From Customer Where customer_id = '" + custid + "' ";
            //InsertUpdateDeleteSQLString(sql);
        //}


        private SqlConnection OpenConnection()
        {
            if (conn.State.ToString()=="Closed"|| conn.State.ToString()=="Broken")
            {
                conn.Open();
            }
            return conn;
        }


          public DataTable executeSelectQuery(string query)
        {
            myCommand = new SqlCommand();
            DataTable dataTable = new DataTable();
            dataTable = null;
            DataSet ds = new DataSet();
            try
            {
                myCommand.Connection = OpenConnection();
                myCommand.CommandText = query;
                myCommand.ExecuteNonQuery();                
                myAdapter.SelectCommand = myCommand;
                myAdapter.Fill(ds);
                dataTable = ds.Tables[0];
            }
            catch 
            {
                Console.Write("Error occured with query: " + query + " \nException:");
                return null;
            }
            finally
            {

            }
            return dataTable;
        }

         public void InsertUpdateDeleteSQLString(string sqlstring)

        {
            conn.Open();
            SqlCommand objcmd = new SqlCommand(sqlstring, conn);
            objcmd.ExecuteNonQuery();
            conn.Close();
        }

         public void UpdateClient(string name, string surname, string ID, string CN1, string CN2, string EM, int age, string HA, int id)

        {
            DataSet ds = new DataSet();
            string sql = "Update tblClient set Name='" + name + "',Surname = '" + surname + "',IDNumber= '" + ID + "',ContactNumber = '" + CN1 + "',ContactNumb2 = '" + CN2 + "',EmailAddress = '" + EM + "',Age = '" + age + "',Address = '" + HA + "' Where ClientID = '" + id + "' ";
            InsertUpdateDeleteSQLString(sql);
        }

         public void UpdateShedule(DateTime d1, DateTime d2, double cost, int id)
         {
             DataSet ds = new DataSet();
             string sql = "Update tblProductInstallation set InstallationCost='" + cost + "',InstallationEndDate = '" + d2 + "',InstallationStartDate= '" + d1 + "' Where InstallationID = '" + id + "' ";
             InsertUpdateDeleteSQLString(sql);
         }

         public void AddUser(string Username, string password, int DepID)
        {
            DataSet ds = new DataSet();
            string sql = "INSERT into tblUsers (UserName,UserPassword,DepartmentID) VALUES ('" + Username + "','" + password + "','" + DepID + "')";
            InsertUpdateDeleteSQLString(sql);
        }

          public void AddShedule(DateTime da1,DateTime da2,double cost, int ClientID)
          {
              DataSet ds = new DataSet();
              string sql = "INSERT into tblProductInstallation (InstallationStartDate,InstallationEndDate,InstallationCost,ClientID) VALUES ('" + da1 + "','" + da2 + "','" + cost + "','" + ClientID + "')";
              InsertUpdateDeleteSQLString(sql);
          }

          public void UpdateTechPersonnel(string name, string surname, string ID, string CN1, string EM, int age, string HA, int id)
         {
             DataSet ds = new DataSet();
             string sql = "Update tblTechnicalPersonnel set Names='" + name + "',Surname = '" + surname + "',IDNumber= '" + ID + "',ContactNumber = '" + CN1 + "',EmailAddress = '" + EM + "',Age = '" + age + "',Address = '" + HA + "' Where PersonnelID = '" + id + "' ";
             InsertUpdateDeleteSQLString(sql);
         }
    }
}
