﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmContract : Form
    {
        int id;
        public frmContract(int ID)
        {
            InitializeComponent();
            id = ID;
            Bind();
        }

        public frmContract()
        {
            InitializeComponent();
        }
        public void Bind()
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = Contract.SearchContract(2);
            lstContract.DataSource = bs;
            lstContract.DisplayMember = "Display";
            cmbStatus.DataBindings.Add(new Binding("Text",bs,"ContractStatus"));
            cmbService.DataBindings.Add(new Binding("Text", bs, "ServiceLevelID"));
            cmbContractType.DataBindings.Add(new Binding("Text", bs, "ContactTypeID"));
            lblID.DataBindings.Add(new Binding("Text", bs, "ContractID"));
        }

        private void frmContract_Load(object sender, EventArgs e)
        {
            BindingSource bs1 = new BindingSource();
            BindingSource bs2 = new BindingSource();
            BindingSource bs3 = new BindingSource();
            Option opt = new Option();
           // bs1.DataSource = opt.Product2();
            lst1.DataSource = bs1;
         //   bs2.DataSource = Option.Product3();
            lst2.DataSource = bs2;
        //    bs3.DataSource = Option.Product4();
            lst3.DataSource = bs3;
            //Option opt = new Option();
            //bs1.DataSource = opt.Product2();
            //lst1.DataSource = bs1;
            //lst1.DisplayMember = "OptionDisplay";
            //lst2.DisplayMember = "Display";
            //lst3.DisplayMember = "Display";
            //lblOpt1.DataBindings.Add(new Binding("Text", bs1, "ProductID"));
            //lblOpt1.DataBindings.Add(new Binding("Text", bs2, "ProductID"));
            //lblOpt1.DataBindings.Add(new Binding("Text", bs3, "ProductID"));
            //lblCost.DataBindings.Add(new Binding("Text", bs1, "Cost"));
            //lblCost.DataBindings.Add(new Binding("Text", bs2, "Cost"));
            //lblCost.DataBindings.Add(new Binding("Text", bs3, "Cost"));

            string[] ContractType = new string[] { "1.A", "2.B", "3.C" };
            string[] Service = new string[] { "1.VVIP", "2.VIP", "3.IP" };
            string[] Status = new string[] { "Active", "Not Active"};
            for (int i = 0; i < 3; i++)
            {
                cmbContractType.Items.Add(ContractType[i]);
            }
            for (int i = 0; i < 3; i++)
            {
                cmbService.Items.Add(Service[i]);
            }
            for (int i = 0; i < 2; i++)
            {
                cmbStatus.Items.Add(Status[i]);
            }

            if (lstContract.Text.ToString()=="")
            {
                btnUpdate.Visible = false;
                gbInstMain.Visible=false;
            }
        }

        private void lstContract_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Contract Contr = new Contract();
            Contr.ContractStatus = cmbContractType.Text.ToString();
            Contr.ContactTypeID =int.Parse(cmbContractType.Text.ToString());
            Contr.ServiceLevelID = int.Parse(cmbService.Text.ToString());

            BLL.BusinessLogic bl = new BusinessLogic();

            if (bl.ContractUpdate(Contr) == true)
            {
                MessageBox.Show("Personnel information updated");
            }
            else
            {
                MessageBox.Show("Failed");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            BLL.BusinessLogic bl = new BusinessLogic();
            Contract cnt = new Contract();
            Random r = new Random();
            int id = r.Next(100000, 999999); ;
            cnt.Identifier = id.ToString();
            double paymet=double.Parse(txtPay.Text.ToString());
            cnt.PaymentMade = paymet;
            
            cnt.SignedDate=DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy"));
            cnt.OptionID=int.Parse(lblOpt1.Text.ToString());
            cnt.ServiceLevelID=int.Parse(cmbService.Text.Substring(0,1).ToString());
            cnt.ClientID=id;
            cnt.ContactTypeID=int.Parse(cmbContractType.Text.Substring(0,1).ToString());
            cnt.ContractStatus=cmbStatus.Text.ToString();

            if (paymet<double.Parse(lblCost.Text.ToString()) ||paymet>double.Parse(lblCost.Text.ToString()))
            {
                MessageBox.Show("Enter the correct Payment");

              if (bl.AddContract(cnt) == true)
                 {
                  MessageBox.Show("Contract information Added","Succeful",MessageBoxButtons.RetryCancel);
                  Clients clientfrm = new Clients();
                  clientfrm.Show();
                }
              else
              {
                  MessageBox.Show("Entry failed try again","Failed",MessageBoxButtons.RetryCancel);
              }
            }
        }

        private void btnInstallation_Click(object sender, EventArgs e)
        {
            //int InstalID=int.Parse(lblID.Text.ToString());
            //frmInstallationRequired frmIsn = new frmInstallationRequired(InstalID);
            //frmIsn.Show();
        }

        private void btnMaintenance_Click(object sender, EventArgs e)
        {
        }
    }
}
