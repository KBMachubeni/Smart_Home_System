﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace SHSystem
{
    public partial class frmPRManagemet : Form
    {
        public frmPRManagemet()
        {
            InitializeComponent();
        }

        Option option = new Option();
        Product product = new Product();
        ComponentClass comp = new ComponentClass();
        Category category = new Category();
        BusinessLogic bl = new BusinessLogic();

        private void frmPRManagemet_Load(object sender, EventArgs e)
        {
            List<Category> Complist = category.CategoryList();
            foreach (var item in Complist)
            {
                cmbCategory.Items.Add(item.name);
            }
        }

        //method for hiding the components columns in data grid view
        public void HideCompColumns()
        {
            dgvComponents.Columns[0].Visible = false;
            dgvComponents.Columns[2].Visible = false;
            dgvComponents.Columns[3].Visible = false;
            dgvComponents.Columns[4].Visible = false;
            dgvComponents.Columns[6].Visible = false;
            dgvComponents.Columns[7].Visible = false;
        }
        //method for hiding the components columns in data grid view
        public void HideProdColumns()
        {
            dgvProducts.Columns[0].Visible = false;
            dgvProducts.Columns[3].Visible = false;
            dgvProducts.Columns[4].Visible = false;
        }
        //method for hiding the components columns in data grid view
        public void HideOptColumns()
        {
            dgvOptions.Columns[1].Visible = false;
            dgvOptions.Columns[2].Visible = false;
            dgvOptions.Columns[3].Visible = false;
            dgvOptions.Columns[4].Visible = false;
            dgvOptions.Columns[6].Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //showing the products in the data grid view
        private void dgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvProducts.CurrentCell.RowIndex;
            int optionID = int.Parse(dgvProducts[0, current].Value.ToString());
            txtProdName.Text = dgvProducts[1, current].Value.ToString();
            txtProdDescript.Text = dgvProducts[2, current].Value.ToString();

            BindingSource bs = new BindingSource();
            
            bs.DataSource = option.OptiontOfProduct(optionID);
            dgvOptions.DataSource = bs;
            HideOptColumns();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            
            bs.DataSource = product.ProductList();
            dgvProducts.DataSource = bs;
            HideProdColumns();
            
        }

        // bind the options off the product to the tetxtboxes
        private void dgvOptions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvOptions.CurrentCell.RowIndex;
            int optionID = int.Parse(dgvOptions[0, current].Value.ToString());
            txtCost.Text = dgvOptions[2, current].Value.ToString();
            txtDescription.Text = dgvOptions[1, current].Value.ToString();

            BindingSource bs = new BindingSource();
            
            bs.DataSource = comp.CompOption(optionID);
            dgvComponents.DataSource = bs;

            HideCompColumns();
        }

        //view components of the product option
        private void Componets_Click(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();

            bs.DataSource = comp.CompList();
            dgvComponents.DataSource = bs;

            HideCompColumns();

        }

        private void dgvComponents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int current = dgvComponents.CurrentCell.RowIndex;
            int CompID = int.Parse(dgvComponents[0, current].Value.ToString());
            txtCompName.Text = dgvComponents[1, current].Value.ToString();
            txtCompCost.Text = dgvComponents[2, current].Value.ToString();
            txtQty.Text = dgvComponents[3, current].Value.ToString();
            txtSerial.Text = dgvComponents[5, current].Value.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();

            bs.DataSource = option.OptiontList();
            dgvOptions.DataSource = bs;
            HideOptColumns();

            HideOptColumns();

        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = product.ProductOnCategoty(cmbCategory.Text.ToString());
            dgvProducts.DataSource = bs;
            HideProdColumns();
        }
        //updating the product
        private void btnUpdateProd_Click(object sender, EventArgs e)
        {
            int current = dgvProducts.CurrentCell.RowIndex;
            int ProdID = int.Parse(dgvProducts[0, current].Value.ToString());
            product.productID = ProdID;
            product.productname=txtProdName.Text;
            product.ProductDescription=txtProdDescript.Text;
            if (bl.ProductUpdate(product)==true)
            {
                MessageBox.Show("Product information updated","Successful transaction", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Product information update failed", "failed transaction", MessageBoxButtons.RetryCancel, MessageBoxIcon.Information);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Main m = new Main();
            m.Show();
            this.Close();
        }

        private void btnUpdateOpt_Click(object sender, EventArgs e)
        {

        }
    }
}
