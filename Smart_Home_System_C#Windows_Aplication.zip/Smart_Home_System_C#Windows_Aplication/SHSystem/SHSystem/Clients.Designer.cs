﻿namespace SHSystem
{
    partial class Clients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Clients));
            this.tbcClients = new System.Windows.Forms.TabControl();
            this.tbpClient = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtPostal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnUpdat = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtConNumber = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.txtIDNumber = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtSurbub = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dgvClient = new System.Windows.Forms.DataGridView();
            this.tbpContract = new System.Windows.Forms.TabPage();
            this.btnAddCont = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnAdd = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnUpdateCont = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblMonthfee = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblOption = new System.Windows.Forms.Label();
            this.lstOption = new System.Windows.Forms.ListBox();
            this.dgvContract = new System.Windows.Forms.DataGridView();
            this.lblCost = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtPay = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lblOptID = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblService = new System.Windows.Forms.Label();
            this.cmbContractType = new System.Windows.Forms.ComboBox();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.lstContract = new System.Windows.Forms.ListBox();
            this.tbpMaint = new System.Windows.Forms.TabPage();
            this.label22 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnAddMaint = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtDiscrpt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbpAdd = new System.Windows.Forms.TabPage();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblOptionCost = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtAddPayment = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.status = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.Conttype = new System.Windows.Forms.ComboBox();
            this.level = new System.Windows.Forms.ComboBox();
            this.Options = new System.Windows.Forms.GroupBox();
            this.dgvOptions = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtAddCode = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtAddSurburb = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtAddEmail = new System.Windows.Forms.TextBox();
            this.txtAddSname = new System.Windows.Forms.TextBox();
            this.txtAddNumber = new System.Windows.Forms.TextBox();
            this.txtAddHome = new System.Windows.Forms.TextBox();
            this.txtAddName = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblUser = new System.Windows.Forms.Label();
            this.btnViewAll = new WindowsFormsControlLibrary1.BunifuThinButton();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgvCalls = new System.Windows.Forms.DataGridView();
            this.tbcClients.SuspendLayout();
            this.tbpClient.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClient)).BeginInit();
            this.tbpContract.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).BeginInit();
            this.tbpMaint.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tbpAdd.SuspendLayout();
            this.Options.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCalls)).BeginInit();
            this.SuspendLayout();
            // 
            // tbcClients
            // 
            this.tbcClients.Controls.Add(this.tbpClient);
            this.tbcClients.Controls.Add(this.tbpContract);
            this.tbcClients.Controls.Add(this.tbpMaint);
            this.tbcClients.Controls.Add(this.tbpAdd);
            this.tbcClients.Controls.Add(this.tabPage1);
            this.tbcClients.Location = new System.Drawing.Point(8, 114);
            this.tbcClients.Name = "tbcClients";
            this.tbcClients.SelectedIndex = 0;
            this.tbcClients.Size = new System.Drawing.Size(737, 461);
            this.tbcClients.TabIndex = 0;
            // 
            // tbpClient
            // 
            this.tbpClient.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpClient.Controls.Add(this.groupBox2);
            this.tbpClient.Controls.Add(this.dgvClient);
            this.tbpClient.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpClient.Location = new System.Drawing.Point(4, 22);
            this.tbpClient.Name = "tbpClient";
            this.tbpClient.Padding = new System.Windows.Forms.Padding(3);
            this.tbpClient.Size = new System.Drawing.Size(729, 435);
            this.tbpClient.TabIndex = 0;
            this.tbpClient.Text = "Client";
            this.tbpClient.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.txtPostal);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnUpdat);
            this.groupBox2.Controls.Add(this.txtEmail);
            this.groupBox2.Controls.Add(this.txtConNumber);
            this.groupBox2.Controls.Add(this.txtSurname);
            this.groupBox2.Controls.Add(this.txtIDNumber);
            this.groupBox2.Controls.Add(this.txtAddress);
            this.groupBox2.Controls.Add(this.txtSurbub);
            this.groupBox2.Controls.Add(this.txtName);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.groupBox2.Location = new System.Drawing.Point(28, 287);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(662, 136);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Update/Delete Client";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(429, 76);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(94, 18);
            this.label31.TabIndex = 48;
            this.label31.Text = "Postal Code";
            // 
            // txtPostal
            // 
            this.txtPostal.Location = new System.Drawing.Point(432, 94);
            this.txtPostal.Multiline = true;
            this.txtPostal.Name = "txtPostal";
            this.txtPostal.Size = new System.Drawing.Size(145, 21);
            this.txtPostal.TabIndex = 47;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(166, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 18);
            this.label9.TabIndex = 46;
            this.label9.Text = "Contact Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(296, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 18);
            this.label8.TabIndex = 45;
            this.label8.Text = "Surburb";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 44;
            this.label5.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(166, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 18);
            this.label4.TabIndex = 43;
            this.label4.Text = "Surname";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(295, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 18);
            this.label3.TabIndex = 42;
            this.label3.Text = "ID Number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(426, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 18);
            this.label2.TabIndex = 41;
            this.label2.Text = "Home Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 18);
            this.label6.TabIndex = 40;
            this.label6.Text = "Email Address";
            // 
            // btnUpdat
            // 
            this.btnUpdat.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdat.BackgroundImage = global::SHSystem.Properties.Resources.blank_black_button_hi;
            this.btnUpdat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdat.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdat.ForeColor = System.Drawing.SystemColors.Control;
            this.btnUpdat.Location = new System.Drawing.Point(580, 44);
            this.btnUpdat.Name = "btnUpdat";
            this.btnUpdat.Size = new System.Drawing.Size(76, 31);
            this.btnUpdat.TabIndex = 20;
            this.btnUpdat.Text = "Update";
            this.btnUpdat.UseVisualStyleBackColor = false;
            this.btnUpdat.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(9, 94);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(151, 21);
            this.txtEmail.TabIndex = 19;
            // 
            // txtConNumber
            // 
            this.txtConNumber.Location = new System.Drawing.Point(169, 94);
            this.txtConNumber.Name = "txtConNumber";
            this.txtConNumber.Size = new System.Drawing.Size(123, 21);
            this.txtConNumber.TabIndex = 18;
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(169, 44);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(123, 21);
            this.txtSurname.TabIndex = 17;
            // 
            // txtIDNumber
            // 
            this.txtIDNumber.Location = new System.Drawing.Point(298, 44);
            this.txtIDNumber.Name = "txtIDNumber";
            this.txtIDNumber.Size = new System.Drawing.Size(125, 21);
            this.txtIDNumber.TabIndex = 16;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(429, 44);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(145, 21);
            this.txtAddress.TabIndex = 15;
            // 
            // txtSurbub
            // 
            this.txtSurbub.Location = new System.Drawing.Point(298, 94);
            this.txtSurbub.Name = "txtSurbub";
            this.txtSurbub.Size = new System.Drawing.Size(125, 21);
            this.txtSurbub.TabIndex = 13;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(9, 44);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(151, 21);
            this.txtName.TabIndex = 12;
            // 
            // dgvClient
            // 
            this.dgvClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClient.Location = new System.Drawing.Point(28, 18);
            this.dgvClient.Name = "dgvClient";
            this.dgvClient.Size = new System.Drawing.Size(662, 263);
            this.dgvClient.TabIndex = 56;
            this.dgvClient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvClient_CellContentClick);
            // 
            // tbpContract
            // 
            this.tbpContract.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpContract.Controls.Add(this.btnAddCont);
            this.tbpContract.Controls.Add(this.btnAdd);
            this.tbpContract.Controls.Add(this.btnUpdateCont);
            this.tbpContract.Controls.Add(this.lblMonthfee);
            this.tbpContract.Controls.Add(this.label15);
            this.tbpContract.Controls.Add(this.lblOption);
            this.tbpContract.Controls.Add(this.lstOption);
            this.tbpContract.Controls.Add(this.dgvContract);
            this.tbpContract.Controls.Add(this.lblCost);
            this.tbpContract.Controls.Add(this.label23);
            this.tbpContract.Controls.Add(this.txtPay);
            this.tbpContract.Controls.Add(this.label24);
            this.tbpContract.Controls.Add(this.lblOptID);
            this.tbpContract.Controls.Add(this.label11);
            this.tbpContract.Controls.Add(this.cmbStatus);
            this.tbpContract.Controls.Add(this.label12);
            this.tbpContract.Controls.Add(this.label13);
            this.tbpContract.Controls.Add(this.lblService);
            this.tbpContract.Controls.Add(this.cmbContractType);
            this.tbpContract.Controls.Add(this.cmbService);
            this.tbpContract.Controls.Add(this.lstContract);
            this.tbpContract.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpContract.Location = new System.Drawing.Point(4, 22);
            this.tbpContract.Name = "tbpContract";
            this.tbpContract.Padding = new System.Windows.Forms.Padding(3);
            this.tbpContract.Size = new System.Drawing.Size(729, 435);
            this.tbpContract.TabIndex = 1;
            this.tbpContract.Text = "Contract";
            this.tbpContract.Click += new System.EventHandler(this.tbpContract_Click);
            // 
            // btnAddCont
            // 
            this.btnAddCont.Activecolor = System.Drawing.Color.Transparent;
            this.btnAddCont.BackColor = System.Drawing.Color.Transparent;
            this.btnAddCont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddCont.BorderRadius = 0;
            this.btnAddCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnAddCont.ButtonText = "    Add New";
            this.btnAddCont.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCont.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAddCont.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAddCont.Iconimage")));
            this.btnAddCont.Iconimage_right = null;
            this.btnAddCont.Iconimage_right_Selected = null;
            this.btnAddCont.Iconimage_Selected = null;
            this.btnAddCont.IconZoom = 90D;
            this.btnAddCont.IsTab = false;
            this.btnAddCont.Location = new System.Drawing.Point(212, 335);
            this.btnAddCont.Name = "btnAddCont";
            this.btnAddCont.Normalcolor = System.Drawing.Color.Transparent;
            this.btnAddCont.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAddCont.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAddCont.selected = false;
            this.btnAddCont.Size = new System.Drawing.Size(154, 55);
            this.btnAddCont.TabIndex = 104;
            this.btnAddCont.Textcolor = System.Drawing.Color.Black;
            this.btnAddCont.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCont.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Activecolor = System.Drawing.Color.Transparent;
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAdd.BorderRadius = 0;
            this.btnAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnAdd.ButtonText = "    Save";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAdd.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAdd.Iconimage")));
            this.btnAdd.Iconimage_right = null;
            this.btnAdd.Iconimage_right_Selected = null;
            this.btnAdd.Iconimage_Selected = null;
            this.btnAdd.IconZoom = 90D;
            this.btnAdd.IsTab = false;
            this.btnAdd.Location = new System.Drawing.Point(398, 335);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Normalcolor = System.Drawing.Color.Transparent;
            this.btnAdd.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnAdd.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAdd.selected = false;
            this.btnAdd.Size = new System.Drawing.Size(164, 55);
            this.btnAdd.TabIndex = 103;
            this.btnAdd.Textcolor = System.Drawing.Color.Black;
            this.btnAdd.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Click += new System.EventHandler(this.btnSaveInfo_Click);
            // 
            // btnUpdateCont
            // 
            this.btnUpdateCont.Activecolor = System.Drawing.Color.Transparent;
            this.btnUpdateCont.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdateCont.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateCont.BorderRadius = 0;
            this.btnUpdateCont.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnUpdateCont.ButtonText = "    Update";
            this.btnUpdateCont.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateCont.Iconcolor = System.Drawing.Color.Transparent;
            this.btnUpdateCont.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnUpdateCont.Iconimage")));
            this.btnUpdateCont.Iconimage_right = null;
            this.btnUpdateCont.Iconimage_right_Selected = null;
            this.btnUpdateCont.Iconimage_Selected = null;
            this.btnUpdateCont.IconZoom = 90D;
            this.btnUpdateCont.IsTab = false;
            this.btnUpdateCont.Location = new System.Drawing.Point(32, 335);
            this.btnUpdateCont.Name = "btnUpdateCont";
            this.btnUpdateCont.Normalcolor = System.Drawing.Color.Transparent;
            this.btnUpdateCont.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnUpdateCont.OnHoverTextColor = System.Drawing.Color.White;
            this.btnUpdateCont.selected = false;
            this.btnUpdateCont.Size = new System.Drawing.Size(146, 55);
            this.btnUpdateCont.TabIndex = 102;
            this.btnUpdateCont.Textcolor = System.Drawing.Color.Black;
            this.btnUpdateCont.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateCont.Click += new System.EventHandler(this.btnUpdateInfo_Click);
            // 
            // lblMonthfee
            // 
            this.lblMonthfee.AutoSize = true;
            this.lblMonthfee.Location = new System.Drawing.Point(595, 230);
            this.lblMonthfee.Name = "lblMonthfee";
            this.lblMonthfee.Size = new System.Drawing.Size(0, 18);
            this.lblMonthfee.TabIndex = 101;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(508, 230);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 18);
            this.label15.TabIndex = 100;
            this.label15.Text = "Monthly Fee :";
            // 
            // lblOption
            // 
            this.lblOption.AutoSize = true;
            this.lblOption.Location = new System.Drawing.Point(664, 240);
            this.lblOption.Name = "lblOption";
            this.lblOption.Size = new System.Drawing.Size(0, 18);
            this.lblOption.TabIndex = 99;
            // 
            // lstOption
            // 
            this.lstOption.FormattingEnabled = true;
            this.lstOption.ItemHeight = 18;
            this.lstOption.Location = new System.Drawing.Point(498, 41);
            this.lstOption.Name = "lstOption";
            this.lstOption.Size = new System.Drawing.Size(214, 130);
            this.lstOption.TabIndex = 88;
            this.lstOption.SelectedIndexChanged += new System.EventHandler(this.lstOption_SelectedIndexChanged);
            // 
            // dgvContract
            // 
            this.dgvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContract.Location = new System.Drawing.Point(32, 41);
            this.dgvContract.Name = "dgvContract";
            this.dgvContract.Size = new System.Drawing.Size(438, 150);
            this.dgvContract.TabIndex = 87;
            this.dgvContract.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(595, 204);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(0, 18);
            this.lblCost.TabIndex = 86;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(511, 204);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(106, 18);
            this.label23.TabIndex = 85;
            this.label23.Text = "Option Cost :";
            // 
            // txtPay
            // 
            this.txtPay.Location = new System.Drawing.Point(588, 266);
            this.txtPay.Name = "txtPay";
            this.txtPay.Size = new System.Drawing.Size(124, 25);
            this.txtPay.TabIndex = 84;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(495, 266);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(127, 18);
            this.label24.TabIndex = 83;
            this.label24.Text = "Make Payment :";
            // 
            // lblOptID
            // 
            this.lblOptID.AutoSize = true;
            this.lblOptID.Location = new System.Drawing.Point(434, 64);
            this.lblOptID.Name = "lblOptID";
            this.lblOptID.Size = new System.Drawing.Size(0, 18);
            this.lblOptID.TabIndex = 81;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(178, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 18);
            this.label11.TabIndex = 74;
            this.label11.Text = "Client Contract";
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Location = new System.Drawing.Point(318, 258);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(136, 26);
            this.cmbStatus.TabIndex = 71;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(176, 230);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 18);
            this.label12.TabIndex = 70;
            this.label12.Text = "Contract Type";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(330, 230);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 18);
            this.label13.TabIndex = 69;
            this.label13.Text = "Status";
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(29, 230);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(105, 18);
            this.lblService.TabIndex = 68;
            this.lblService.Text = "Service Level";
            // 
            // cmbContractType
            // 
            this.cmbContractType.FormattingEnabled = true;
            this.cmbContractType.Location = new System.Drawing.Point(179, 258);
            this.cmbContractType.Name = "cmbContractType";
            this.cmbContractType.Size = new System.Drawing.Size(121, 26);
            this.cmbContractType.TabIndex = 67;
            // 
            // cmbService
            // 
            this.cmbService.ForeColor = System.Drawing.Color.Yellow;
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Location = new System.Drawing.Point(32, 258);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(121, 26);
            this.cmbService.TabIndex = 66;
            // 
            // lstContract
            // 
            this.lstContract.FormattingEnabled = true;
            this.lstContract.ItemHeight = 18;
            this.lstContract.Location = new System.Drawing.Point(53, 80);
            this.lstContract.Name = "lstContract";
            this.lstContract.Size = new System.Drawing.Size(411, 58);
            this.lstContract.TabIndex = 65;
            // 
            // tbpMaint
            // 
            this.tbpMaint.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpMaint.Controls.Add(this.label22);
            this.tbpMaint.Controls.Add(this.label14);
            this.tbpMaint.Controls.Add(this.groupBox1);
            this.tbpMaint.Controls.Add(this.dataGridView1);
            this.tbpMaint.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpMaint.Location = new System.Drawing.Point(4, 22);
            this.tbpMaint.Name = "tbpMaint";
            this.tbpMaint.Size = new System.Drawing.Size(729, 435);
            this.tbpMaint.TabIndex = 3;
            this.tbpMaint.Text = "Product Maintenace";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(287, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(165, 18);
            this.label22.TabIndex = 50;
            this.label22.Text = "Product Maintenance";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(651, -18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 18);
            this.label14.TabIndex = 49;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAddMaint);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtDiscrpt);
            this.groupBox1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(54, 289);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(619, 126);
            this.groupBox1.TabIndex = 48;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Maintenace";
            // 
            // btnAddMaint
            // 
            this.btnAddMaint.BackColor = System.Drawing.Color.Transparent;
            this.btnAddMaint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddMaint.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMaint.Location = new System.Drawing.Point(455, 38);
            this.btnAddMaint.Name = "btnAddMaint";
            this.btnAddMaint.Size = new System.Drawing.Size(128, 37);
            this.btnAddMaint.TabIndex = 72;
            this.btnAddMaint.Text = "Add";
            this.btnAddMaint.UseVisualStyleBackColor = false;
            this.btnAddMaint.Click += new System.EventHandler(this.btnAddMaint_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(14, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 18);
            this.label18.TabIndex = 64;
            this.label18.Text = "Description";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(455, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(128, 37);
            this.button1.TabIndex = 62;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtDiscrpt
            // 
            this.txtDiscrpt.Location = new System.Drawing.Point(17, 39);
            this.txtDiscrpt.Multiline = true;
            this.txtDiscrpt.Name = "txtDiscrpt";
            this.txtDiscrpt.Size = new System.Drawing.Size(432, 74);
            this.txtDiscrpt.TabIndex = 61;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(54, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(619, 209);
            this.dataGridView1.TabIndex = 47;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tbpAdd
            // 
            this.tbpAdd.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tbpAdd.Controls.Add(this.btnCancel);
            this.tbpAdd.Controls.Add(this.lblOptionCost);
            this.tbpAdd.Controls.Add(this.button2);
            this.tbpAdd.Controls.Add(this.txtAddPayment);
            this.tbpAdd.Controls.Add(this.label32);
            this.tbpAdd.Controls.Add(this.label33);
            this.tbpAdd.Controls.Add(this.status);
            this.tbpAdd.Controls.Add(this.label34);
            this.tbpAdd.Controls.Add(this.label35);
            this.tbpAdd.Controls.Add(this.label36);
            this.tbpAdd.Controls.Add(this.Conttype);
            this.tbpAdd.Controls.Add(this.level);
            this.tbpAdd.Controls.Add(this.Options);
            this.tbpAdd.Controls.Add(this.dataGridView2);
            this.tbpAdd.Controls.Add(this.groupBox3);
            this.tbpAdd.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbpAdd.Location = new System.Drawing.Point(4, 22);
            this.tbpAdd.Name = "tbpAdd";
            this.tbpAdd.Size = new System.Drawing.Size(729, 435);
            this.tbpAdd.TabIndex = 4;
            this.tbpAdd.Text = "Make Sale";
            this.tbpAdd.Click += new System.EventHandler(this.tbpAdd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(647, 381);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(66, 36);
            this.btnCancel.TabIndex = 97;
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblOptionCost
            // 
            this.lblOptionCost.AutoSize = true;
            this.lblOptionCost.Location = new System.Drawing.Point(391, 347);
            this.lblOptionCost.Name = "lblOptionCost";
            this.lblOptionCost.Size = new System.Drawing.Size(0, 18);
            this.lblOptionCost.TabIndex = 96;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(353, 383);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(44, 32);
            this.button2.TabIndex = 95;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtAddPayment
            // 
            this.txtAddPayment.Location = new System.Drawing.Point(591, 343);
            this.txtAddPayment.Name = "txtAddPayment";
            this.txtAddPayment.Size = new System.Drawing.Size(122, 25);
            this.txtAddPayment.TabIndex = 94;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(351, 350);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(50, 18);
            this.label32.TabIndex = 95;
            this.label32.Text = "Cost :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(483, 353);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(102, 15);
            this.label33.TabIndex = 93;
            this.label33.Text = "Make Payment:";
            // 
            // status
            // 
            this.status.FormattingEnabled = true;
            this.status.Location = new System.Drawing.Point(591, 305);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(126, 26);
            this.status.TabIndex = 92;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(460, 279);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(111, 18);
            this.label34.TabIndex = 91;
            this.label34.Text = "Contract Type";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(603, 277);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(53, 18);
            this.label35.TabIndex = 90;
            this.label35.Text = "Status";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(351, 278);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(105, 18);
            this.label36.TabIndex = 89;
            this.label36.Text = "Service Level";
            // 
            // Conttype
            // 
            this.Conttype.FormattingEnabled = true;
            this.Conttype.Location = new System.Drawing.Point(463, 307);
            this.Conttype.Name = "Conttype";
            this.Conttype.Size = new System.Drawing.Size(116, 26);
            this.Conttype.TabIndex = 88;
            // 
            // level
            // 
            this.level.ForeColor = System.Drawing.Color.Yellow;
            this.level.FormattingEnabled = true;
            this.level.Location = new System.Drawing.Point(354, 306);
            this.level.Name = "level";
            this.level.Size = new System.Drawing.Size(97, 26);
            this.level.TabIndex = 87;
            // 
            // Options
            // 
            this.Options.Controls.Add(this.dgvOptions);
            this.Options.Location = new System.Drawing.Point(347, 23);
            this.Options.Name = "Options";
            this.Options.Size = new System.Drawing.Size(376, 241);
            this.Options.TabIndex = 49;
            this.Options.TabStop = false;
            this.Options.Text = "Options";
            // 
            // dgvOptions
            // 
            this.dgvOptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOptions.Location = new System.Drawing.Point(6, 19);
            this.dgvOptions.Name = "dgvOptions";
            this.dgvOptions.Size = new System.Drawing.Size(364, 216);
            this.dgvOptions.TabIndex = 48;
            this.dgvOptions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOptions_CellContentClick);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(-33, -149);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 31;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.txtAddCode);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.txtAddSurburb);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.txtID);
            this.groupBox3.Controls.Add(this.txtAddEmail);
            this.groupBox3.Controls.Add(this.txtAddSname);
            this.groupBox3.Controls.Add(this.txtAddNumber);
            this.groupBox3.Controls.Add(this.txtAddHome);
            this.groupBox3.Controls.Add(this.txtAddName);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Location = new System.Drawing.Point(22, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(319, 395);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Personal Information";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label19.Location = new System.Drawing.Point(203, 333);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 15);
            this.label19.TabIndex = 46;
            this.label19.Text = "Postal Code";
            // 
            // txtAddCode
            // 
            this.txtAddCode.Location = new System.Drawing.Point(203, 352);
            this.txtAddCode.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddCode.Name = "txtAddCode";
            this.txtAddCode.Size = new System.Drawing.Size(82, 25);
            this.txtAddCode.TabIndex = 45;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label20.Location = new System.Drawing.Point(19, 333);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 15);
            this.label20.TabIndex = 44;
            this.label20.Text = "Surburb";
            // 
            // txtAddSurburb
            // 
            this.txtAddSurburb.Location = new System.Drawing.Point(23, 352);
            this.txtAddSurburb.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddSurburb.Name = "txtAddSurburb";
            this.txtAddSurburb.Size = new System.Drawing.Size(172, 25);
            this.txtAddSurburb.TabIndex = 43;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label25.Location = new System.Drawing.Point(23, 280);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 15);
            this.label25.TabIndex = 41;
            this.label25.Text = "Home Address";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label26.Location = new System.Drawing.Point(23, 226);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 15);
            this.label26.TabIndex = 40;
            this.label26.Text = "Email Address";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label27.Location = new System.Drawing.Point(23, 172);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(110, 15);
            this.label27.TabIndex = 39;
            this.label27.Text = "Contact Number";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label28.Location = new System.Drawing.Point(23, 75);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(65, 15);
            this.label28.TabIndex = 38;
            this.label28.Text = "Surname";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label29.Location = new System.Drawing.Point(23, 123);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(76, 15);
            this.label29.TabIndex = 37;
            this.label29.Text = "ID Number";
            // 
            // txtID
            // 
            this.txtID.Location = new System.Drawing.Point(26, 143);
            this.txtID.Margin = new System.Windows.Forms.Padding(4);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(255, 25);
            this.txtID.TabIndex = 36;
            // 
            // txtAddEmail
            // 
            this.txtAddEmail.Location = new System.Drawing.Point(26, 249);
            this.txtAddEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddEmail.Name = "txtAddEmail";
            this.txtAddEmail.Size = new System.Drawing.Size(255, 25);
            this.txtAddEmail.TabIndex = 35;
            // 
            // txtAddSname
            // 
            this.txtAddSname.Location = new System.Drawing.Point(26, 94);
            this.txtAddSname.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddSname.Name = "txtAddSname";
            this.txtAddSname.Size = new System.Drawing.Size(255, 25);
            this.txtAddSname.TabIndex = 34;
            // 
            // txtAddNumber
            // 
            this.txtAddNumber.Location = new System.Drawing.Point(26, 191);
            this.txtAddNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddNumber.Name = "txtAddNumber";
            this.txtAddNumber.Size = new System.Drawing.Size(255, 25);
            this.txtAddNumber.TabIndex = 33;
            // 
            // txtAddHome
            // 
            this.txtAddHome.Location = new System.Drawing.Point(26, 299);
            this.txtAddHome.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddHome.Multiline = true;
            this.txtAddHome.Name = "txtAddHome";
            this.txtAddHome.Size = new System.Drawing.Size(255, 21);
            this.txtAddHome.TabIndex = 32;
            // 
            // txtAddName
            // 
            this.txtAddName.Location = new System.Drawing.Point(25, 45);
            this.txtAddName.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddName.Name = "txtAddName";
            this.txtAddName.Size = new System.Drawing.Size(260, 25);
            this.txtAddName.TabIndex = 30;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.label30.Location = new System.Drawing.Point(23, 26);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 15);
            this.label30.TabIndex = 29;
            this.label30.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Search By ID:";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(7, 88);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(190, 20);
            this.txtSearch.TabIndex = 2;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Transparent;
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(203, 87);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(26, 20);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(582, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 18);
            this.label10.TabIndex = 60;
            this.label10.Text = "User :";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(268, 14);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(195, 20);
            this.dateTimePicker1.TabIndex = 98;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.Color.Transparent;
            this.lblUser.Location = new System.Drawing.Point(685, 20);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 13);
            this.lblUser.TabIndex = 99;
            // 
            // btnViewAll
            // 
            this.btnViewAll.BackColor = System.Drawing.Color.Transparent;
            this.btnViewAll.BackgroundImage = global::SHSystem.Properties.Resources.blank_black_button_hi;
            this.btnViewAll.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewAll.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btnViewAll.ButtonText = "All Clients";
            this.btnViewAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnViewAll.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewAll.ForeColor = System.Drawing.Color.Transparent;
            this.btnViewAll.ForeColorHoverState = System.Drawing.Color.White;
            this.btnViewAll.Iconimage = null;
            this.btnViewAll.IconVisible = true;
            this.btnViewAll.IconZoom = 90D;
            this.btnViewAll.ImageIconOverlay = false;
            this.btnViewAll.Location = new System.Drawing.Point(585, 78);
            this.btnViewAll.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(152, 51);
            this.btnViewAll.TabIndex = 100;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Franklin Gothic Demi", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.button3.Location = new System.Drawing.Point(2, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(33, 30);
            this.button3.TabIndex = 101;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = global::SHSystem.Properties.Resources.blank_black_button_hi;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.Control;
            this.button4.Location = new System.Drawing.Point(580, 84);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(76, 31);
            this.button4.TabIndex = 49;
            this.button4.Text = "Add Client";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgvCalls);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(729, 435);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Text = "View Client Calls";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgvCalls
            // 
            this.dgvCalls.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dgvCalls.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCalls.Location = new System.Drawing.Point(48, 22);
            this.dgvCalls.Name = "dgvCalls";
            this.dgvCalls.Size = new System.Drawing.Size(634, 211);
            this.dgvCalls.TabIndex = 0;
            this.dgvCalls.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCalls_CellContentClick);
            // 
            // Clients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SHSystem.Properties.Resources._3__3157003_technology_network_loop_background;
            this.ClientSize = new System.Drawing.Size(831, 618);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnViewAll);
            this.Controls.Add(this.lblUser);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbcClients);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Clients";
            this.Text = "ClientManagement";
            this.Load += new System.EventHandler(this.Clients_Load);
            this.tbcClients.ResumeLayout(false);
            this.tbpClient.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClient)).EndInit();
            this.tbpContract.ResumeLayout(false);
            this.tbpContract.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).EndInit();
            this.tbpMaint.ResumeLayout(false);
            this.tbpMaint.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tbpAdd.ResumeLayout(false);
            this.tbpAdd.PerformLayout();
            this.Options.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCalls)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tbcClients;
        private System.Windows.Forms.TabPage tbpClient;
        private System.Windows.Forms.TabPage tbpContract;
        private System.Windows.Forms.TabPage tbpMaint;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnUpdat;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtConNumber;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox txtIDNumber;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtSurbub;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DataGridView dgvClient;
        private System.Windows.Forms.Label lblOptID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.ComboBox cmbContractType;
        private System.Windows.Forms.ComboBox cmbService;
        private System.Windows.Forms.ListBox lstContract;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtDiscrpt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtPay;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DataGridView dgvContract;
        private System.Windows.Forms.ListBox lstOption;
        private System.Windows.Forms.Button btnAddMaint;
        private System.Windows.Forms.TabPage tbpAdd;
        private System.Windows.Forms.GroupBox Options;
        private System.Windows.Forms.DataGridView dgvOptions;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtAddCode;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtAddSurburb;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtAddEmail;
        private System.Windows.Forms.TextBox txtAddSname;
        private System.Windows.Forms.TextBox txtAddNumber;
        private System.Windows.Forms.TextBox txtAddHome;
        private System.Windows.Forms.TextBox txtAddName;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblOptionCost;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtAddPayment;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox status;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox Conttype;
        private System.Windows.Forms.ComboBox level;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txtPostal;
        private System.Windows.Forms.Label lblOption;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lblMonthfee;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuFlatButton btnAddCont;
        private Bunifu.Framework.UI.BunifuFlatButton btnAdd;
        private Bunifu.Framework.UI.BunifuFlatButton btnUpdateCont;
        private WindowsFormsControlLibrary1.BunifuThinButton btnViewAll;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgvCalls;
    }
}