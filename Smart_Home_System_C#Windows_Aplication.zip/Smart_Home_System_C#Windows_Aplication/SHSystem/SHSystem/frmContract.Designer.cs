﻿namespace SHSystem
{
    partial class frmContract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstContract = new System.Windows.Forms.ListBox();
            this.cmbService = new System.Windows.Forms.ComboBox();
            this.cmbContractType = new System.Windows.Forms.ComboBox();
            this.lblService = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.gbInstMain = new System.Windows.Forms.GroupBox();
            this.btnInstallation = new System.Windows.Forms.Button();
            this.btnMaintenance = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblOpt1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lst3 = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lst2 = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lst1 = new System.Windows.Forms.ListBox();
            this.txtPay = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.gbInstMain.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstContract
            // 
            this.lstContract.FormattingEnabled = true;
            this.lstContract.Location = new System.Drawing.Point(25, 55);
            this.lstContract.Name = "lstContract";
            this.lstContract.Size = new System.Drawing.Size(411, 69);
            this.lstContract.TabIndex = 0;
            this.lstContract.SelectedIndexChanged += new System.EventHandler(this.lstContract_SelectedIndexChanged);
            // 
            // cmbService
            // 
            this.cmbService.ForeColor = System.Drawing.Color.Yellow;
            this.cmbService.FormattingEnabled = true;
            this.cmbService.Location = new System.Drawing.Point(25, 179);
            this.cmbService.Name = "cmbService";
            this.cmbService.Size = new System.Drawing.Size(121, 21);
            this.cmbService.TabIndex = 1;
            // 
            // cmbContractType
            // 
            this.cmbContractType.FormattingEnabled = true;
            this.cmbContractType.Location = new System.Drawing.Point(172, 179);
            this.cmbContractType.Name = "cmbContractType";
            this.cmbContractType.Size = new System.Drawing.Size(121, 21);
            this.cmbContractType.TabIndex = 3;
            // 
            // lblService
            // 
            this.lblService.AutoSize = true;
            this.lblService.Location = new System.Drawing.Point(22, 151);
            this.lblService.Name = "lblService";
            this.lblService.Size = new System.Drawing.Size(72, 13);
            this.lblService.TabIndex = 4;
            this.lblService.Text = "Service Level";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(312, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(169, 151);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Contract Type";
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Location = new System.Drawing.Point(315, 179);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(121, 21);
            this.cmbStatus.TabIndex = 7;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(16, 324);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 8;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(352, 329);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 9;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(171, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Client Contract";
            // 
            // gbInstMain
            // 
            this.gbInstMain.Controls.Add(this.btnInstallation);
            this.gbInstMain.Controls.Add(this.btnMaintenance);
            this.gbInstMain.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbInstMain.Location = new System.Drawing.Point(111, 298);
            this.gbInstMain.Name = "gbInstMain";
            this.gbInstMain.Size = new System.Drawing.Size(217, 54);
            this.gbInstMain.TabIndex = 52;
            this.gbInstMain.TabStop = false;
            this.gbInstMain.Text = "Product Status";
            // 
            // btnInstallation
            // 
            this.btnInstallation.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnInstallation.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnInstallation.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstallation.Location = new System.Drawing.Point(4, 24);
            this.btnInstallation.Name = "btnInstallation";
            this.btnInstallation.Size = new System.Drawing.Size(98, 24);
            this.btnInstallation.TabIndex = 54;
            this.btnInstallation.Text = "Installation";
            this.btnInstallation.UseVisualStyleBackColor = false;
            this.btnInstallation.Click += new System.EventHandler(this.btnInstallation_Click);
            // 
            // btnMaintenance
            // 
            this.btnMaintenance.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.btnMaintenance.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMaintenance.Font = new System.Drawing.Font("Modern No. 20", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMaintenance.Location = new System.Drawing.Point(114, 24);
            this.btnMaintenance.Name = "btnMaintenance";
            this.btnMaintenance.Size = new System.Drawing.Size(87, 24);
            this.btnMaintenance.TabIndex = 53;
            this.btnMaintenance.Text = "Maintenace";
            this.btnMaintenance.UseVisualStyleBackColor = false;
            this.btnMaintenance.Click += new System.EventHandler(this.btnMaintenance_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(16, 294);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 53;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblOpt1
            // 
            this.lblOpt1.AutoSize = true;
            this.lblOpt1.Location = new System.Drawing.Point(771, 66);
            this.lblOpt1.Name = "lblOpt1";
            this.lblOpt1.Size = new System.Drawing.Size(0, 13);
            this.lblOpt1.TabIndex = 57;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lst3);
            this.groupBox4.Location = new System.Drawing.Point(458, 254);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(307, 98);
            this.groupBox4.TabIndex = 55;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Home Safety Management";
            // 
            // lst3
            // 
            this.lst3.FormattingEnabled = true;
            this.lst3.Location = new System.Drawing.Point(10, 25);
            this.lst3.Name = "lst3";
            this.lst3.Size = new System.Drawing.Size(286, 56);
            this.lst3.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lst2);
            this.groupBox3.Location = new System.Drawing.Point(458, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(307, 90);
            this.groupBox3.TabIndex = 56;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Home Convenience Management";
            // 
            // lst2
            // 
            this.lst2.FormattingEnabled = true;
            this.lst2.Location = new System.Drawing.Point(10, 21);
            this.lst2.Name = "lst2";
            this.lst2.Size = new System.Drawing.Size(286, 56);
            this.lst2.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lst1);
            this.groupBox2.Location = new System.Drawing.Point(458, 55);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(307, 97);
            this.groupBox2.TabIndex = 54;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Home Energy Management";
            // 
            // lst1
            // 
            this.lst1.FormattingEnabled = true;
            this.lst1.Location = new System.Drawing.Point(15, 22);
            this.lst1.Name = "lst1";
            this.lst1.Size = new System.Drawing.Size(286, 56);
            this.lst1.TabIndex = 0;
            // 
            // txtPay
            // 
            this.txtPay.Location = new System.Drawing.Point(315, 230);
            this.txtPay.Name = "txtPay";
            this.txtPay.Size = new System.Drawing.Size(121, 20);
            this.txtPay.TabIndex = 61;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(312, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 13);
            this.label4.TabIndex = 60;
            this.label4.Text = "Make Payment";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(195, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 62;
            this.label5.Text = "Cost :";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Location = new System.Drawing.Point(235, 222);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(0, 13);
            this.lblCost.TabIndex = 63;
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Location = new System.Drawing.Point(427, 30);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(0, 13);
            this.lblID.TabIndex = 64;
            // 
            // frmContract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 367);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.lblCost);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPay);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblOpt1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gbInstMain);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblService);
            this.Controls.Add(this.cmbContractType);
            this.Controls.Add(this.cmbService);
            this.Controls.Add(this.lstContract);
            this.Name = "frmContract";
            this.Text = "frmContract";
            this.Load += new System.EventHandler(this.frmContract_Load);
            this.gbInstMain.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstContract;
        private System.Windows.Forms.ComboBox cmbService;
        private System.Windows.Forms.ComboBox cmbContractType;
        private System.Windows.Forms.Label lblService;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbInstMain;
        private System.Windows.Forms.Button btnInstallation;
        private System.Windows.Forms.Button btnMaintenance;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblOpt1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox lst3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox lst2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lst1;
        private System.Windows.Forms.TextBox txtPay;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblID;
    }
}