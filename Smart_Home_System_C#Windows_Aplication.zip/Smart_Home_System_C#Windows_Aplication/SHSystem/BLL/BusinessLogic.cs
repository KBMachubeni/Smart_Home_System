﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using BC;
using DAL;

namespace BLL
{
    public class BusinessLogic
    {
        StoredProcedures SPs = new StoredProcedures();

        public bool EmployeeUpdate(Employee employee)
        {
            return SPs.UpdateEmployee(employee);
        }
    }
}
