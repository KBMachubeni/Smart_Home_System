﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using BC;
using DAL;

namespace BLL
{
    class StoredProcedures
    {
        DAL.dbConnection connection = new dbConnection();

        public bool UpdateEmployee(Employee employee)
        {
            SqlParameter[] parameters = new SqlParameter[]
		{
            new SqlParameter("@id", employee.EmployeeID),
			new SqlParameter("@name", employee.Name),
			new SqlParameter("@Surname", employee.Surname),
			new SqlParameter("@IdNumber", employee.IdNumber),
			new SqlParameter("@ContactNumber", employee.ContactNumber),
			new SqlParameter("@EmailAddress", employee.Email),
			new SqlParameter("@Age", employee.Age),
			new SqlParameter("@AddressNumber", employee.Address),
			new SqlParameter("@Surburb", employee.Surburb),
            new SqlParameter("@PostalCode", employee.postalCode)
		};

            return connection.CRU("sp_UpdateEmployee", CommandType.StoredProcedure, parameters);
        }
    }
}
